import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2, urllib

path = xbmc.translatePath('special://home/addons/service.galaxyupdate')

installed = xbmc.translatePath("special://home/addons/service.galaxyupdate/installed_version.txt")
latest = xbmc.translatePath("special://home/addons/service.galaxyupdate/latest_version.txt")
#dialog       =  xbmcgui.Dialog()
#dialog.ok("Reminder", "[COLOR yellow]If you haven't turned on your device in a while[/COLOR]", "      Please give KODI 5 minutes to warm up")
def path():
	if not os.path.exists(path):
		os.mkdir(path)

#url = 'http://tiny.cc/buildver'
#urllib.urlretrieve(url, latest)


file_i = open(installed)
file_i.close()

file_l = open(latest, 'r')
checksum_latest = file_l.read()
file_l.close()

def check(checksum):
	datafile = file(installed)
	updated = False
	for line in datafile:
		if checksum in line:
			updated = True
			break
	return updated

def wizard():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                #dialog = xbmcgui.Dialog()
                #if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    #dialog = xbmcgui.Dialog()
                    #dialog.ok("WaterTV", "Packages Successfuly Removed")
	return
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("WaterTV", "Sorry we were not able to remove Package Files", "[COLOR yellow]:([/COLOR]")			
	

if check(checksum_latest):
	wizard()
else:
	wizard()
