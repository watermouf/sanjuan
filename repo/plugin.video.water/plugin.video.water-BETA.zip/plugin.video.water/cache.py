import xbmc, xbmcgui

def recenttv():
   # print url,name
    pluginsearchurls = ['plugin://plugin.video.tvmix/?mode=1&name=New%20Latest%20Episodes&url=http%3a%2f%2fwww.watchepisodes1.com%2f',\
             'plugin://plugin.video.1channel/?mode=GetFilteredResults&section=tv&sort=date',\
             'plugin://plugin.video.allinone/?mode=GetTitles1&numOfPages=2&section=ALL&startPage=1&url=http%3a%2f%2fawesomedl.ru%2f%2f',\
             'plugin://plugin.video.origin2/?action=calendar&url=added',\
             
             ]
    names = ['TVMix','PrimeWire/1Channel','AWDL','Origin',]
    dialog = xbmcgui.Dialog()
    index = dialog.select('Choose a video source', names)

    if index >= 0:
        plugname = pluginsearchurls[index]
        print 'plugname',plugname
        xbmc.executebuiltin('ActivateWindow(10025,'+plugname+',return)')
    else: quit()		

def recentmovies():
   # print url,name
    pluginsearchurls = ['plugin://plugin.video.origin2/?action=movies&url=trending,return',\
             'plugin://plugin.video.phstreams/?action=directory&url=http%3a%2f%2fphoenixtv.offshorepastebin.com%2freleases%2fmain.xml,return',\
             'plugin://plugin.video.origin2/?action=movies&url=added,return',\
             'plugin://plugin.video.VidTime/?mode=NMR,return',\
             
             ]
    names = ['Trending','Feature Films','Recently Added','1 Click Movies',]
    dialog = xbmcgui.Dialog()
    index = dialog.select('Choose a video source', names)

    if index >= 0:
        plugname = pluginsearchurls[index]
        print 'plugname',plugname
        xbmc.executebuiltin('ActivateWindow(10025,'+plugname+')')
    else: 
        #dialog = xbmcgui.Dialog()
        #dialog.ok('Choose a video source', names)
        quit()		
        dialog = xbmcgui.Dialog()
        dialog.ok('Choose a video source', '','')

#################################
####### POPUP TEXT BOXES ########
#################################
		

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes('WaterTV', 'TEST')

def donation():
    TextBoxes('WaterTV', 'TEST')		