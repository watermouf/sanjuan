def wizard3(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    #dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp = xbmcgui.DialogProgress()
    dp.create(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    dontkillxbmc()

def BUILDMENU():
    addDir('Fresh Start',BASEURL,6,'http://vignette1.wikia.nocookie.net/scream-queens/images/8/88/Update-icon.png/revision/latest?cb=20150927230935',FANART,'') 
    setView('movies', 'MAIN')
	
def MAINTENANCE():
    #addDir('DELETE CACHE','url',4,ART+'deletecache.png',FANART,'')
    #addDir('IVUE TV GUIDE RESET','url',11,ART+'reset.jpg',FANART,'')
    #addDir('FRESH START','url',6,ART+'freshstart.jpg',FANART,'')
    #addDir('DELETE PACKAGES','url',7,ART+'deletepackages.jpg',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://icons.iconarchive.com/icons/chrisbanks2/cold-fusion-hd/128/speed-test-icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'') 
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    addDir('MORE TOOLS2',BASEURL,3,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    setView('movies', 'MAIN')
    setView('movies', 'MAIN')

def INDEX_off():
    link = OPEN_URL('http://tiny.cc/wizardtxt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
	addDir(name,url,1,iconimage,fanart,description)
    addDir('Web Browser',BASEURL,9,'http://findicons.com/files/icons/1715/gion/128/internet_web_browser.png',FANART,'')
    addDir('File Manager',BASEURL,16,'http://files.softicons.com/download/system-icons/crystal-project-icons-by-everaldo-coelho/png/256x256/apps/file-manager.png',FANART,'')	
    addDir('System Info',BASEURL,17,'http://findicons.com/files/icons/1261/sticker_system/256/get_info.png',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://cdn.appstorm.net/iphone.appstorm.net/files/2011/02/SpeedTest-Icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'')
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')	
    #addDir('DONATE',BASEURL,3,ART+'donate.jpg',FANART,'') 
    #addDir('waterS BUILD',url,4,ART+'icon.png',FANART,'')
    setView('movies', 'MAIN')