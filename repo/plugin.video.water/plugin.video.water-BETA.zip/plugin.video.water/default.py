import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
import ntpath
import zipfile
import speedtest
import socket
import webbrowser
#import subprocess
#from t0mm0.common.net import Net as net

VERSION = "1.0.0"
PATH = "WaterTV" 
AddonTitle="WaterTV"
addon_id = 'plugin.video.water'
AddonID='plugin.video.water'

H = 'http://'
BASEURL = "http://null.com"
base='http://repo.none.com/repo'  
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

#net = Net()
dialog = xbmcgui.Dialog()
ADDON = xbmcaddon.Addon(id=addon_id)
dialog       =  xbmcgui.Dialog()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))



#EXCLUDES     = ['skin.confluence','plugin.video.water','weather.yahoo','metadata.album.universal','metadata.common.allmusic.com','metadata.common.fanart.tv','metadata.common.htbackdrops.com','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.common.theaudiodb.com','metadata.common.themoviedb.org','metadata.musicvideos.theaudiodb.com','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck','metadata.artists.universal','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','metadata.themoviedb.org','script.module.addon.common'

EXCLUDES     = ['plugin.video.water','script.module.addon.common','weather.yahoo','service.xbmc.versioncheck','skin.confluence'] 


EXCLUDES_ADDONS =['weather.yahoo','skin.water2','skin.confluence','service.xbmc.versioncheck','service.subtitles.opensubtitles','service.library.data.provider','service.galaxyupdate','script.video.F4mProxy','script.supafav','script.module.youtube.dl','script.module.urlresolver','script.module.TheYid.common','script.module.t1mlib','script.module.t0mm0.common','script.module.stem','script.module.socksipy','script.module.six','script.module.singledispatch','script.module.simplejson','script.module.simple.downloader','script.module.requests','script.module.pyxbmct','script.module.pycaption','script.module.pyamf','script.module.parsedom','script.module.myconnpy','script.module.metahandler','script.module.mechanize','script.module.livestreamer','script.module.liveresolver','script.module.httplib2','script.module.html5lib','script.module.futures','script.module.free.cable.database','script.module.elementtree','script.module.dnspython','script.module.cssutils','script.module.coveapi','script.module.beautifulsoup4','script.module.beautifulsoup','script.module.axel.downloader','script.module.addon.signals','script.module.addon.common','script.favourites','script.common.plugin.cache','script.autoruns','screensaver.atv4','resource.language.en_us','resource.language.en_gb','repo.water.3rdparty','repo.water','plugin.video.water','plugin.video.f4mTester','plugin.program.super.favourites','metadata.tvdb.com','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com']

EXCLUDES_USERDATA = ['script.trakt','script.skinshortcuts','plugin.video.origin2','plugin.video.1channel','plugin.program.water.notifications','plugin.program.super.favourites','general.data','gen.data','weather.yahoo','plugin.video.salts','plugin.video.water','plugin.video.israelive']

EXCLUDES_REFRESH     = ['media','userdata','script.trakt','general.data','gen.data','weather.yahoo','plugin.video.salts','superrepo.kodi.isengard.all','skin.water2','skin.confluence','service.xbmc.versioncheck','service.subtitles.opensubtitles','service.library.data.provider','service.galaxyupdate','script.video.F4mProxy','script.supafav','script.module.youtube.dl','script.module.urlresolver','script.module.TheYid.common','script.module.t1mlib','script.module.t0mm0.common','script.module.stem','script.module.socksipy','script.module.six','script.module.singledispatch','script.module.simplejson','script.module.simple.downloader','script.module.requests','script.module.pyxbmct','script.module.pycaption','script.module.pyamf','script.module.parsedom','script.module.myconnpy','script.module.metahandler','script.module.mechanize','script.module.livestreamer','script.module.liveresolver','script.module.israeliveresolver','script.module.httplib2','script.module.html5lib','script.module.futures','script.module.free.cable.database','script.module.elementtree','script.module.dnspython','script.module.cssutils','script.module.coveapi','script.module.beautifulsoup4','script.module.beautifulsoup','script.module.axel.downloader','script.module.addon.signals','script.module.addon.common','script.favourites','script.extendedinfo','script.exodus.artwork','script.common.plugin.cache','script.autoruns','screensaver.atv4','resource.language.en_us','resource.language.en_gb','repository.zachmorris','repository.xunitytalk','repository.xbmcplus.xbmc','repository.xbmchub','repository.xbmc.org','repository.xbmc-israel','repository.VinManJSV','repository.tknorris.beta','repository.titan.addons','repository.The_Silencer','repository.teammaniac','repository.spoyser','repository.shani','repository.shaneyrepos','repository.schismtv.official','repository.projectmrnetwork','repository.podgod','repository.openeleq','repository.noobsandnerds','repository.natko1412','repository.metalkettle','repository.meta','repository.merlin','repository.mdrepo','repository.lunatixz','repository.kodil','repository.Kinkin','repository.istream','repository.HalowTV','repository.Goliath','repository.GenieTv','repository.filmkodi.com','repository.exodus','repository.entertainmentrepo','repository.eldorado','repository.dudehere.plugins','repository.dokinl','repository.Cosmixrepo','repository.coldkeys','repository.bulldogstreams','repository.BlazeRepo','repository.aresproject','repo.water.3rdparty','repo.water','plugin.video.ZemTV-shani','plugin.video.yt-crime','plugin.video.youtube','plugin.video.wral','plugin.video.wnbc','plugin.video.water','plugin.video.wabc','plugin.video.VidTime','plugin.video.veetle','plugin.video.ustvvod','plugin.video.tgun','plugin.video.teevee','plugin.video.SportsDevil','plugin.video.smithsonian','plugin.video.prosport','plugin.video.phstreams','plugin.video.pftvso','plugin.video.origin2','plugin.video.israelive','plugin.video.historytube','plugin.video.funniermoments','plugin.video.f4mTester','plugin.video.documentarytube','plugin.video.DecadoDocs','plugin.video.ccloudtv','plugin.video.castaway','plugin.video.allinone','plugin.video.1channel','plugin.stream.vaughnlive.tv','plugin.program.water.notifications','plugin.program.video.node.editor','plugin.program.super.favourites','metadata.tvdb.com','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com']

addon_id        = 'plugin.video.water'
ADDON           = xbmcaddon.Addon(id=addon_id)
selfAddon       = xbmcaddon.Addon(id=addon_id)
datapath        = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
user            = selfAddon.getSetting('wusername')
passw           = selfAddon.getSetting('wpassword')
cookie_file     = os.path.join(os.path.join(datapath,''), 'water.lwp')

import cache
import kill
import clear
import login


global domid
domid = 'http://water.esy.es'
	
#socket.setdefaulttimeout(60)
#if user == '' or passw == '':
#    if os.path.exists(cookie_file):
#        try: os.remove(cookie_file)
#        except: pass    
#    login.login()

 
    	

#def startupcheck():	
#    socket.setdefaulttimeout(60)
#    if user == '' or passw == '':
#        if os.path.exists(cookie_file):
#           try: os.remove(cookie_file)
#           except: pass 
#        login.login()	   
#login.startupcheck()

login.startupcheck()

def INDEX():
    #login.check123()
    link = login.OPEN_URL(domid+'/amember/content/f/id/7/').replace('\n','').replace('\r','')
    #print link
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
	addDir(name,url,1,iconimage,fanart,description)
    addDir('Web Browser',BASEURL,9,'http://findicons.com/files/icons/1715/gion/128/internet_web_browser.png',FANART,'')
    #addDir('File Manager',BASEURL,16,'http://files.softicons.com/download/system-icons/crystal-project-icons-by-everaldo-coelho/png/256x256/apps/file-manager.png',FANART,'')	
    #addDir('System Info',BASEURL,17,'http://findicons.com/files/icons/1261/sticker_system/256/get_info.png',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://cdn.appstorm.net/iphone.appstorm.net/files/2011/02/SpeedTest-Icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'')
    addDir('Clear TEMP',BASEURL,78,'',FANART,'')
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')	
    setView('movies', 'MAIN')

def wizard(name,url,description): 
    dp = xbmcgui.DialogProgress()
    dp.create("WaterTV","Clearing Cache", 'Please Wait','')
    #SILENTFRESH(params)
    ClearAddonData()
    xbmc.sleep(5000)
    dp.update(0,"", "Downloading Update Please Wait")
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    #dp.create("WaterTV","Downloading Update", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    clear.ClearJunk()
    kill.killxbmc()
	
def armdownlr(name,url,description):
    confirm=xbmcgui.Dialog()
    if confirm.yesno(name,description,"","","Back","Download"):
        dp = xbmcgui.DialogProgress()
        dp.create("Download","Downloading...",name,'')
        lib = xbmc.translatePath(os.path.join('sdcard','Download',name +'.apk'))
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)
        time.sleep(1)
        dialog.ok("Installation instructions","1) Exit Kodi 2) Open Android file manager","3) Navigate to Download folder","4) Click on APK file to install")
        xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop)")
	
def wizard2(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    kill.dontkillxbmc()
     
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
  
#dp = xbmcgui.DialogProgress()
#dp.create("TEST","TEST1", 'TEST2','OK')
login.check123()
    
if mode==None or url==None or len(url)<1:
    INDEX()
elif mode==1:
    wizard(name,url,description)
		
elif mode==2:
    #BUILDMENU()
	CATEGORIES()

elif mode==3:
	armdownlr(name,url,description)
		
elif mode==4:
    BUILDMENU()
		
elif mode==5:
        wizard2(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       DeletePackages(url)
       deletecachefiles(url)	   
elif mode==8:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=More/Settings/Maintenance/More Tools",return)')
elif mode==9:
        #xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/webbrowser.py)')
		webbrowser.platform2()
elif mode==10:
    #deletecachefiles(url)
    xbmc.executebuiltin('UpdateAddonRepos') 
    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin('ActivateWindow(10040,addons://outdated/)')     
elif mode==15:
       xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/speedtest.py)')
elif mode==16:
       xbmc.executebuiltin('ActivateWindow(FileManager)')
elif mode==17:
       xbmc.executebuiltin('ActivateWindow(systeminfo)')
elif mode==18:	   
	   loginpro()
elif mode==20: #recent movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=trending",return)')
	   #cache.recentmovies()
elif mode==21: #recent tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Recently Added",return)')
elif mode==22: #new tv shows
       #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=premiere",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvmix/?mode=3&url=http%3a%2f%2fwww.watchepisodes1.com%2fhome%2fnew-series",return)')
elif mode==23: #movie years
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieYears",return)')
elif mode==24: #movie genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieGenres",return)')
elif mode==25: #tv genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvGenres",return)')
elif mode==26: #TV Networks
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/TV onDemand",return)')
elif mode==27: #movie actors
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=moviePersons",return)')	 
elif mode==29: #boxsets
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.phstreams/?action=directory&url=http://tnpb.offshorepastebin.com/Directories/Movies%20Directories/Boxsets%20Directory.xml",return)')	   
elif mode==30: #search movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies/Search",return)')
elif mode==31: #search tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Search",return)')
elif mode==40: #movies root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies",return)')
elif mode==41: #movies browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies/Browse",return)')	   
elif mode==50: #tv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows",return)')	
elif mode==51: #tv browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows/Browse",return)')
elif mode==60: #livetv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV",return)')
elif mode==61: #livetv providers
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Providers",return)')   
elif mode==62: #livetv News
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=News",return)')
elif mode==63: #livetv Sports
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Sports",return)') 
elif mode==64: #livetv Foregin
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Foregin",return)')
elif mode==65: #livetv Shows
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Shows",return)')
elif mode==70: #search widget
       xbmc.executebuiltin('ActivateWindow(1107)')	 
	   
	   
#<favourite name="" thumb="">PlayMedia(&quot;plugin://plugin.video.water/?url=null&amp;mode=19&quot;)</favourite>	   
xbmcplugin.endOfDirectory(int(sys.argv[1]))
