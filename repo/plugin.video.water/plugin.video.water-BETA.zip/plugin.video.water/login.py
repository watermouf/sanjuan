import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import re
import urllib2,urllib

dialog = xbmcgui.Dialog()
domid = 'http://water.esy.es'
addon_id        = 'plugin.video.water'
ADDON           = xbmcaddon.Addon(id=addon_id)
selfAddon       = xbmcaddon.Addon(id=addon_id)
datapath        = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
user            = selfAddon.getSetting('wusername')
passw           = selfAddon.getSetting('wpassword')
cookie_file     = os.path.join(os.path.join(datapath,''), 'water.lwp')
loginpass = base64.b64decode('UHJvIFN1YnNjcmlwdGlvbg==')
import socket
from addon.common.addon import Addon
from addon.common.net import Net as net

def startupcheck():	
    socket.setdefaulttimeout(60)
    if user == '' or passw == '':
        if os.path.exists(cookie_file):
           try: os.remove(cookie_file)
           except: pass 
        login()

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def login():		 
    #ret = dialog.yesno('Update 2.0', 'Please enter your assigned username and password','If you dont have these check your emails','Or contact support for further instructions','Cancel','Login')
    ret = dialog.yesno('waterTV', 'Please enter your username & password','Or contact support for further instructions',"",'Cancel','Login')
    if ret == 1:
        keyb = xbmc.Keyboard('', 'Enter Username')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            username=search
            keyb = xbmc.Keyboard('', 'Enter Password:')
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText()
                password=search
                selfAddon.setSetting('wusername',username)
                selfAddon.setSetting('wpassword',password)
    if ret == 0:
	    #dialog.close(waterTV)
        quit()
	
	
def check123():
    #dp.close() 
    dp = xbmcgui.DialogProgress()
    dp.create("WaterTV","                                  Please Wait", '                             Veryfing Account','')
    setCookie(domid+'/amember/member')
    response = net().http_GET(domid+'/amember/member')
    if not loginpass in response.content:
        
        #dialog.ok('Update 2.0', 'An error has ocurred logging in','Please check your details','')
        #xbmc.executebuiltin('Addon.OpenSettings(plugin.video.water),return')
        login()
        quit()

	
		
def setCookie(srDomain):
    html = net().http_GET(srDomain).content
    r = re.findall(r'<input type="hidden" name="(.+?)" value="(.+?)" />', html, re.I)
    post_data = {}
    post_data['amember_login'] = user
    post_data['amember_pass'] = passw
    for name, value in r:
        post_data[name] = value
    net().http_GET(domid+'/amember/member')
    net().http_POST(domid+'/amember/member',post_data)
    net().save_cookies(cookie_file)
    net().set_cookies(cookie_file)		