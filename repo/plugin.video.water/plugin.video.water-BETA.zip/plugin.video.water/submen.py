def recenttv():
   # print url,name
    pluginsearchurls = ['plugin://plugin.video.tvmix/?mode=1&amp;name=New%20Latest%20Episodes&amp;url=http%3a%2f%2fwww.watchepisodes1.com%2f',\
             'plugin://plugin.video.channelpear/',\
             'plugin://plugin.video.dragon.sports/',\
             'plugin://plugin.video.MoneySports/S',\
			 'plugin://plugin.video.NJMSoccer/',\
			 'plugin://plugin.video.phstreams/',\
			 'plugin://plugin.video.SportsDevil/',\
			 'plugin://plugin.video.ZemTV-shani/',\
			 'plugin://plugin.video.VidTime/',\
			 'plugin://plugin.video.prosport/',\
             
             ]
    names = ['Origin3 - Trending','Channelpear','Dragon.sports','MoneySports','NJM Soccer','Phoenix','Sports Devil','ZEM Streams','VidTime','ProSports',]
    dialog = xbmcgui.Dialog()
    index = dialog.select('Choose a video source', names)

    if index >= 0:
        plugname = pluginsearchurls[index]
        print 'plugname',plugname
        xbmc.executebuiltin('ActivateWindow(10025,'+plugname+',return)')	