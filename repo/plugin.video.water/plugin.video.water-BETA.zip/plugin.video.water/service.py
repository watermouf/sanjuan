import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2, urllib

path = xbmc.translatePath('special://home/addons/plugin.video.water')

installed = xbmc.translatePath("special://home/addons/plugin.video.water/installed_version.txt")
latest = xbmc.translatePath("special://home/addons/plugin.video.water/latest_version.txt")
#dialog       =  xbmcgui.Dialog()
#dialog.ok("Reminder", "[COLOR yellow]If you haven't turned on your device in a while[/COLOR]", "      Please give KODI 5 minutes to warm up")
def path():
	if not os.path.exists(path):
		os.mkdir(path)

url = 'http://tiny.cc/buildver'
urllib.urlretrieve(url, latest)


file_i = open(installed)
file_i.close()

file_l = open(latest, 'r')
checksum_latest = file_l.read()
file_l.close()

def check(checksum):
	datafile = file(installed)
	updated = False
	for line in datafile:
		if checksum in line:
			updated = True
			break
	return updated

def wizard():
	choice = xbmcgui.Dialog().yesno('Update', 'Update available', 'Select OK to start updating', yeslabel='Cancel',nolabel='OK')
	if choice == 1:
		return
	elif choice == 0:
		#xbmc.executebuiltin("RunAddon(plugin.video.water)")
		xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.water/?url=http%3A%2F%2F&mode=1&name=UPDATE)')
		#file_i = open(installed, "w")
		#file_i.write(checksum_latest)
		#file_i.close()
		#file_i = open(installed)
		#checksum_updated = file_i.read()
		#file_i.close()

if check(checksum_latest):
	xbmc.sleep(1000)
else:
	wizard()
