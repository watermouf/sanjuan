import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net as net
import ntpath
import zipfile
import speedtest
import socket
import webbrowser
import subprocess

#from t0mm0.common.net import Net as net
VERSION = "1.0.0"
PATH = "WaterTV" 
AddonTitle="WaterTV"
addon_id = 'plugin.video.water'
AddonID='plugin.video.water'



H = 'http://'
BASEURL = "http://null.com"
base='http://repo.none.com/repo'  
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
  

          

#net = Net()
dialog = xbmcgui.Dialog()
ADDON = xbmcaddon.Addon(id=addon_id)
dialog       =  xbmcgui.Dialog()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))

DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');

#EXCLUDES     = ['skin.confluence','plugin.video.water','weather.yahoo','metadata.album.universal','metadata.common.allmusic.com','metadata.common.fanart.tv','metadata.common.htbackdrops.com','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.common.theaudiodb.com','metadata.common.themoviedb.org','metadata.musicvideos.theaudiodb.com','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck','metadata.artists.universal','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','metadata.themoviedb.org','script.module.addon.common'] 

EXCLUDES     = ['packages','script.module.tknorris.shared','plugin.video.water','weather.yahoo','skin.confluence','service.xbmc.versioncheck','script.module.addon.common','metadata.tvdb.com','metadata.themoviedb.org','metadata.musicvideos.theaudiodb.com','metadata.common.themoviedb.org','metadata.common.theaudiodb.com','metadata.common.musicbrainz.org','metadata.common.last.fm','metadata.common.imdb.com','metadata.common.htbackdrops.com','metadata.common.fanart.tv','metadata.common.allmusic.com','metadata.artists.universal','metadata.album.universal','plugin.video.1channel','plugin.program.water.notifications','plugin.video.ZemTV-shani','resource.language.en_us'] 


EXCLUDES_ADDONS =['packages','script.module.tknorris.shared','weather.yahoo','skin.water2','skin.confluence','service.xbmc.versioncheck','service.subtitles.opensubtitles','service.library.data.provider','service.galaxyupdate','script.video.F4mProxy','script.supafav','script.module.youtube.dl','script.module.urlresolver','script.module.TheYid.common','script.module.t1mlib','script.module.t0mm0.common','script.module.stem','script.module.socksipy','script.module.six','script.module.singledispatch','script.module.simplejson','script.module.simple.downloader','script.module.requests','script.module.pyxbmct','script.module.pycaption','script.module.pyamf','script.module.parsedom','script.module.myconnpy','script.module.metahandler','script.module.mechanize','script.module.livestreamer','script.module.liveresolver','script.module.httplib2','script.module.html5lib','script.module.futures','script.module.free.cable.database','script.module.elementtree','script.module.dnspython','script.module.cssutils','script.module.coveapi','script.module.beautifulsoup4','script.module.beautifulsoup','script.module.axel.downloader','script.module.addon.signals','script.module.addon.common','script.favourites','script.common.plugin.cache','script.autoruns','screensaver.atv4','resource.language.en_us','resource.language.en_gb','repo.water.3rdparty','repo.water','plugin.video.water','plugin.video.f4mTester','plugin.program.super.favourites','metadata.tvdb.com','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','metadata.album.universal','metadata.artists.universal','metadata.common.musicbrainz.org','service.library.data.provider','plugin.video.1channel','plugin.video.ZemTV-shani','metadata.themoviedb.org','metadata.common.fanart.tv']

EXCLUDES_USERDATA = ['script.trakt','script.skinshortcuts','plugin.program.water.notifications','general.data','gen.data','weather.yahoo','plugin.video.water','plugin.video.israelive']

EXCLUDES2     = ['media','userdata','script.trakt','general.data','gen.data','weather.yahoo','script.module.tknorris.shared','skin.water2','skin.confluence','service.xbmc.versioncheck','service.subtitles.opensubtitles','service.library.data.provider','service.galaxyupdate','script.video.F4mProxy','script.supafav','script.module.youtube.dl','script.module.urlresolver','script.module.TheYid.common','script.module.t1mlib','script.module.t0mm0.common','script.module.stem','script.module.socksipy','script.module.six','script.module.singledispatch','script.module.simplejson','script.module.simple.downloader','script.module.requests','script.module.pyxbmct','script.module.pycaption','script.module.pyamf','script.module.parsedom','script.module.myconnpy','script.module.metahandler','script.module.mechanize','script.module.livestreamer','script.module.liveresolver','script.module.httplib2','script.module.html5lib','script.module.futures','script.module.free.cable.database','script.module.elementtree','script.module.dnspython','script.module.cssutils','script.module.coveapi','script.module.beautifulsoup4','script.module.beautifulsoup','script.module.axel.downloader','script.module.addon.signals','script.module.addon.common','script.favourites','script.extendedinfo','script.exodus.artwork','script.common.plugin.cache','script.autoruns','screensaver.atv4','resource.language.en_us','resource.language.en_gb','repository.zachmorris','repository.xunitytalk','repository.xbmcplus.xbmc','repository.xbmchub','repository.xbmc.org','repository.tknorris.beta','repository.shani','repository.podgod','repository.openeleq','repository.noobsandnerds','repository.natko1412','repository.metalkettle','repository.meta','repository.merlin','repository.mdrepo','repository.lunatixz','repository.kodil','repository.Kinkin','repository.istream','repository.exodus','repository.coldkeys','repo.water.3rdparty','repo.water','plugin.video.ZemTV-shani','plugin.video.yt-crime','plugin.video.youtube','plugin.video.wral','plugin.video.wnbc','plugin.video.water','plugin.video.wabc','plugin.video.smithsonian','plugin.video.prosport','plugin.video.phstreams','plugin.video.origin2','plugin.video.historytube','plugin.video.funniermoments','plugin.video.f4mTester','plugin.video.documentarytube','plugin.video.DecadoDocs','plugin.video.ccloudtv','plugin.video.1channel','plugin.stream.vaughnlive.tv','plugin.program.water.notifications','plugin.program.video.node.editor','plugin.program.super.favourites','metadata.tvdb.com','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','plugin.video.meta']




addon_id        = 'plugin.video.water'
ADDON           = xbmcaddon.Addon(id=addon_id)
selfAddon       = xbmcaddon.Addon(id=addon_id)
datapath        = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
user            = selfAddon.getSetting('wusername')
passw           = selfAddon.getSetting('wpassword')
cookie_file     = os.path.join(os.path.join(datapath,''), 'water.lwp')

def correctPVR ():#line:117
	PVRaddon =xbmcaddon .Addon ('plugin.video.playklub')#line:119
	username =PVRaddon .getSetting (id ='Username')#line:120
	password =PVRaddon .getSetting (id ='Password')#line:121
	username =playersklub
	password =playersklub
	disableLIVETV ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":false},"id":1}'#line:122
	disablePVR ='{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":false},"id":1}'#line:123
	enableLIVETV ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'#line:122
	enablePVR ='{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'#line:123
	disablePVRDEMO ='{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'#line:124
	m3uURL ="http://dns.theplayersklub.us:2095/get.php?username="+username +"&password="+password +"&type=m3u_plus&output=ts"#line:125
	EPGurl ="http://dns.theplayersklub.us:2095/xmltv.php?username="+username +"&password="+password +"&type=m3u_plus&output=ts"#line:126
	xbmc .executeJSONRPC (disablePVR )#line:129
	xbmc .executeJSONRPC (disableLIVETV )#line:128
	xbmc .executeJSONRPC (enableLIVETV )#line:128
	xbmc .executeJSONRPC (enablePVR )#line:129
	xbmc .executeJSONRPC (disablePVRDEMO )#line:130
	PVRaddon =xbmcaddon .Addon ('pvr.iptvsimple')#line:132
	PVRaddon .setSetting (id ='m3uUrl',value =m3uURL )#line:133
	PVRaddon .setSetting (id ='epgUrl',value =EPGurl )#line:134
	PVRaddon .setSetting (id ='m3uCache',value ="false")#line:135
	PVRaddon .setSetting (id ='epgCache',value ="false")#line:136
	PVRaddon .setSetting (id ='m3uPathType',value ="1")#line:136
	PVRaddon .setSetting (id ='epgPathType',value ="1")#line:136
	#xbmc.sleep(5000)
	#xbmc .executebuiltin ('ActivateWindow(TVChannels)')#line:141
	quit()

	
def login():		
    
    #ret = dialog.yesno('Update 2.0', 'Please enter your assigned username and password','If you dont have these check your emails','Or contact support for further instructions','Cancel','Login')
    ret = dialog.yesno('waterTV', 'Please enter your username & password','Or contact support for further instructions',"",'Cancel','Login')
    if ret == 1:
        keyb = xbmc.Keyboard('', 'Enter Username')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            username=search
            keyb = xbmc.Keyboard('', 'Enter Password:')
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText()
                password=search
                selfAddon.setSetting('wusername',username)
                selfAddon.setSetting('wpassword',password)
    if ret == 0:
	    #dialog.close(waterTV)
        quit()
		
#socket.setdefaulttimeout(60)
#if user == '' or passw == '':
#    if os.path.exists(cookie_file):
#        try: os.remove(cookie_file)
#        except: pass    
#    login()


	
user = selfAddon.getSetting('wusername')
passw = selfAddon.getSetting('wpassword')
domid = 'http://watertv.hol.es'
domid2 = 'http://tiny.cc'
loginpass = base64.b64decode('UHJvIFN1YnNjcmlwdGlvbg==')

def check123():
    #dp.close() 
    dp = xbmcgui.DialogProgress()
    dp.create("WaterTV","                                  Please Wait", '                             Veryfing Account','')
    setCookie(domid+'/amember/member')
    #setCookie(domid+'/watertvholes')
	
    response = net().http_GET(domid+'/amember/member')
    if not loginpass in response.content:
        
        dialog.ok('Update 2.0', 'An error has ocurred logging in','Please check your details','')
        xbmc.executebuiltin('Addon.OpenSettings(plugin.video.water),return')
        #login()
        quit()
		
#check123()	

def INDEX():
    #check123()
    #link = OPEN_URL(domid+'/amember/content/f/id/7/').replace('\n','').replace('\r','')
    link = OPEN_URL(domid2+'/wizardtxt').replace('\n','').replace('\r','')
    #print link
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
	addDir(name,url,1,iconimage,fanart,description)
    addDir('Web Browser',BASEURL,9,'http://findicons.com/files/icons/1715/gion/128/internet_web_browser.png',FANART,'')
    #addDir('Check for Updates',BASEURL,10,'http://vignette1.wikia.nocookie.net/scream-queens/images/8/88/Update-icon.png/revision/latest?cb=20150927230935',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://cdn.appstorm.net/iphone.appstorm.net/files/2011/02/SpeedTest-Icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'')
    #addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    #addDir('File Manager',BASEURL,16,'http://files.softicons.com/download/system-icons/crystal-project-icons-by-everaldo-coelho/png/256x256/apps/file-manager.png',FANART,'')	
    #addDir('System Info',BASEURL,17,'http://findicons.com/files/icons/1261/sticker_system/256/get_info.png',FANART,'')
    #addDir('ClearTEMP',BASEURL,4,'',FANART,'')
    #addDir('ClearADDONS',BASEURL,11,'',FANART,'')	
    setView('movies', 'MAIN')


def wizard(name,url,description): 
    dp = xbmcgui.DialogProgress()
    #dp.create("WaterTV","Clearing Cache", 'Please Wait','')
    #xbmc.sleep(5000)
    #dp.update(0,"", "Downloading Update Please Wait")
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    dp.create("WaterTV","Downloading Update", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dp.update(0,"", "Cleaing Cache")
    ClearAddonData()
    SILENTFRESH(params)
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    ClearJunk()
    killxbmc()

	
def BUILDMENU():
    addDir('Fresh Start',BASEURL,6,'http://vignette1.wikia.nocookie.net/scream-queens/images/8/88/Update-icon.png/revision/latest?cb=20150927230935',FANART,'') 
    setView('movies', 'MAIN')
	
def MAINTENANCE():
    #addDir('DELETE CACHE','url',4,ART+'deletecache.png',FANART,'')
    #addDir('IVUE TV GUIDE RESET','url',11,ART+'reset.jpg',FANART,'')
    #addDir('FRESH START','url',6,ART+'freshstart.jpg',FANART,'')
    #addDir('DELETE PACKAGES','url',7,ART+'deletepackages.jpg',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://icons.iconarchive.com/icons/chrisbanks2/cold-fusion-hd/128/speed-test-icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'') 
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    addDir('MORE TOOLS2',BASEURL,3,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    setView('movies', 'MAIN')
    setView('movies', 'MAIN')
	
def armdownlr(name,url,description):
    confirm=xbmcgui.Dialog()
    if confirm.yesno(name,description,"","","Cancel","Install"):
        dp = xbmcgui.DialogProgress()
        dp.create("Download","Downloading...",name,'')
        #lib = xbmc.translatePath(os.path.join('sdcard','Download',name +'.apk'))
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, name+'.apk')
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)
        time.sleep(1)
        #dialog.ok("Installation instructions","1) Exit Kodi 2) Open Android file manager","3) Navigate to Download folder","4) Click on APK file to install")
        #xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop)")
        xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        
	
	
def wizard2(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    dontkillxbmc()
	
	
def wizard3(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    #dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp = xbmcgui.DialogProgress()
    dp.create(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    dontkillxbmc()	
#################################
####### POPUP TEXT BOXES ########
#################################
def setCookie(srDomain):
    html = net().http_GET(srDomain).content
    r = re.findall(r'<input type="hidden" name="(.+?)" value="(.+?)" />', html, re.I)
    post_data = {}
    post_data['amember_login'] = user
    post_data['amember_pass'] = passw
    for name, value in r:
        post_data[name] = value
    net().http_GET(domid+'/amember/member')
    net().http_POST(domid+'/amember/member',post_data)
    net().save_cookies(cookie_file)
    net().set_cookies(cookie_file)		

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes('WaterTV', 'TEST')

def donation():
    TextBoxes('WaterTV', 'TEST')
    
def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    
                    dialog.ok("WaterTV", "Packages Successfuly Removed")
    except: 
        
        dialog.ok("WaterTV", "Sorry we were not able to remove Package Files", "[COLOR yellow]:([/COLOR]")			
	
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
                
    # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    
    dialog.ok("WaterTV", " All Cache Files Removed", "[COLOR yellow]![/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################
def dontkillxbmc():
   
  dialog.ok('Update', 'All Done','') 
  quit()
  
def ClearAddonData():
    addons_cache_path = xbmc.translatePath(os.path.join('special://home/addons', ''))
    try:    
        for root, dirs, files in os.walk(addons_cache_path,topdown=True):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES_ADDONS]
            #file_count = 0
            #file_count += len(files)
        # Count files and give option to delete
            #if file_count > 0: 
            #for f in files:
			#    try: os.remove(os.path.join(root,name)) 
            #for d in dirs:			
                 
            for f in files:
                os.remove(os.path.join(root,f))
                #os.unlink(os.path.join(root, f))
            for d in dirs:
               os.rmdir(os.path.join(root,d))
               #shutil.rmtree(os.path.join(root, d))
    except: 
		pass

    addons_cache_path = xbmc.translatePath(os.path.join('special://home/addons', ''))
    try:    
        for root, dirs, files in os.walk(addons_cache_path,topdown=True):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES_ADDONS]
            #file_count = 0
            #file_count += len(files)
        # Count files and give option to delete
            #if file_count > 0: 
            #for f in files:
			#    try: os.remove(os.path.join(root,name)) 
            #for d in dirs:			
                 
            for f in files:
                #os.remove(os.path.join(root,f))
                os.unlink(os.path.join(root, f))
            for d in dirs:
                #os.rmdir(os.path.join(root,d))
                shutil.rmtree(os.path.join(root, d))
    except: 
		pass		
		
    addon_data_cache_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', ''))
    try:    
        for root, dirs, files in os.walk(addon_data_cache_path,topdown=True):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES_USERDATA]		      
            for f in files:
                os.remove(os.path.join(root,f))
                #os.unlink(os.path.join(root, f))
            for d in dirs:
                os.rmdir(os.path.join(root,d))
                #shutil.rmtree(os.path.join(root, d))
    except: 
		pass		
		
    addon_data_cache_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', ''))
    try:    
        for root, dirs, files in os.walk(addon_data_cache_path,topdown=True):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES_USERDATA]		      
            for f in files:
                #os.remove(os.path.join(root,f))
                os.unlink(os.path.join(root, f))
            for d in dirs:
                #os.rmdir(os.path.join(root,d))
                shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
def ClearJunk():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
#    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
#    try:    
#        for root, dirs, files in os.walk(temp_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass

#    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
#    try:    
#        for root, dirs, files in os.walk(xbmc_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass


	
	
	
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    try:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass

    axel_cache_path = os.path.join(xbmc.translatePath('special://home/userdata/addon_data/script.module.axel.downloader'), '')
    try:    
        for root, dirs, files in os.walk(axel_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
    allinone_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.allinone/icons'), '')
    try:    
        for root, dirs, files in os.walk(allinone_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    ccloud_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.ccloud/resources/icons'), '')
    try:    
        for root, dirs, files in os.walk(ccloud_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    vidtime_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.VidTime/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(vidtime_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    castaway_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.castaway/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(castaway_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass    
	
    sportsdevil_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.SportsDevil/resources/images/'), '')
    try:    
        for root, dirs, files in os.walk(sportsdevil_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass

def killxbmc():		
    #dialog.ok("IMPORTANT", "If Kodi does [COLOR red][B]NOT[/B][/COLOR] close after you click [COLOR yellow]OK[/COLOR]", "[B]YOU MUST PULL THE [COLOR red]POWER[/COLOR] ON YOUR DEVICE[/B]",'')
    #if choice == 1:
    #    return
    #elif choice == 0:
    #    pass
 			

    

	myplatform = platform()
	print "Platform: " + str(myplatform)

	try:
		os._exit(1)
	except:
		pass

	if myplatform == 'osx':  # OSX
		print "############   try osx force close  #################"
		try:
			os.system('killall -9 XBMC')
		except:
			pass
		try:
			os.system('killall -9 Kodi')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'linux':  # Linux
		print "############   try linux force close  #################"
		try:
			os.system('killall XBMC')
		except:
			pass
		try:
			os.system('killall Kodi')
		except:
			pass
		try:
			os.system('killall -9 xbmc.bin')
		except:
			pass
		try:
			os.system('killall -9 kodi.bin')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'android':  # Android

		print "############   try android force close  #################"

		try:
			os._exit(1)
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.kodi')
		except:
			pass
		#try:
		#	os.system('adb shell am force-stop org.xbmc.xbmc')
		#except:
		#	pass
		#try:
		#	os.system('adb shell am force-stop org.xbmc')
		#except:
		#	pass
		try:
			os.system('adb shell am force-stop com.semperpax.spmc16')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.spmc16')
		except:
			pass
		time.sleep(5)
		plugintools.message(AddonTitle,"Press the HOME button on your remote and [COLOR=red][b]FORCE STOP[/b][/COLOR] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows':  # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", "Use task manager and NOT ALT F4")
	else:  # ATV
		print "############   try atv force close  #################"
		try:
			os.system('killall AppleTV')
		except:
			pass
		print "############   try raspbmc force close  #################"  # OSMC / Raspbmc
		try:
			os.system('sudo initctl stop kodi')
		except:
			pass
		try:
			os.system('sudo initctl stop xbmc')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")

		
def killxbmc_old():		
    dialog.ok("IMPORTANT", "If Kodi does [COLOR red][B]NOT[/B][/COLOR] close after you click [COLOR yellow]OK[/COLOR]", "[B]YOU MUST PULL THE [COLOR red]POWER[/COLOR] ON YOUR DEVICE[/B]",'')
    #if choice == 1:
    #    return
    #elif choice == 0:
    #    pass
 			

    

    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass    
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")
	killxbmc()
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    		
		
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
		
def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with WaterTV, Please Restart Kodi and go to Programs / WaterTV")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with WaterTV, Please Restart Kodi and go to Programs / WaterTV")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Please Restart Kodi and go to Programs / WaterTV",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)

	
def SILENTFRESH(params):
    addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
    xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
    try:
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                except:
                    if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
            for name in dirs:
                try: os.rmdir(os.path.join(root,name)) 
                #shutil.rmtree(os.path.join(root, name))
                except: pass
	for name in dirs:
                #try: os.rmdir(os.path.join(root,name)) 
                try: shutil.rmtree(os.path.join(root, name))
                except: pass	
	for name in files:
	    #try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                os.remove(os.path.join(root,name))

    except: pass 

def REFRESH_TEMP(params):
    addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
    xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
    try:
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES2]
            for name in files:
                try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                except:
                    if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
            for name in dirs:
                try: os.rmdir(os.path.join(root,name)) 
                #shutil.rmtree(os.path.join(root, name))
                except: pass
	for name in dirs:
                #try: os.rmdir(os.path.join(root,name)) 
                try: shutil.rmtree(os.path.join(root, name))
                except: pass	
	for name in files:
	    #try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                os.remove(os.path.join(root,name))

    except: pass 
	
def REFRESH(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to refresh your","system?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES2]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"Your system has been refreshed")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"Your system has been refreshed")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Please Restart Kodi and go to Programs / WaterTV",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        


#appname="Fire TV Launcher"
#packagename="com.amazon.tv.launcher"
def launcher(appname,downld,packagename):
	packagepath = os.popen('pm path %s' % packagename).read()
	if packagepath:
		xbmc.executebuiltin('XBMC.StartAndroidActivity("%s")' % packagename)
	#else:	
    #if packagepath:
		#xbmc.executebuiltin('XBMC.StartAndroidActivity("%s")' % packagename)
	#if NOT packagepath:
	    #xbmc.executebuiltin('XBMC.StartAndroidActivity("%s")' % packagename)
	else:
		
		armdownlr(appname,downld,'Install ' +appname)
		#xbmcgui.Dialog().ok('App Not Installed', 'This is only a shortcut.  Please install the "%s" app (%s) and try again.' % (appname, packagename))
		#xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.water/?url=%s&mode=3&name=%s&description=Install %s",return)' % (downld,appname,appname))
		#xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Shows",return)' % (appname, packagename))
		


		
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
  
#dp = xbmcgui.DialogProgress()
#dp.create("TEST","TEST1", 'TEST2','')

#check123()	

	   
if mode==None or url==None or len(url)<1:
        INDEX()
elif mode==1:
        wizard(name,url,description)
		
elif mode==2:
        #BUILDMENU()
		CATEGORIES()

elif mode==3:
    #facebook()
	armdownlr(name,url,description)
		
elif mode==4:
        ClearJunk()
		
elif mode==5:
        wizard2(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       DeletePackages(url)		
elif mode==8:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=More/Settings/Maintenance/More Tools",return)')
elif mode==9:
        #xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/webbrowser.py)')
		webbrowser.platform2()
elif mode==10:
    #deletecachefiles(url)
    #xbmc.executebuiltin('UpdateAddonRepos') 
    #xbmc.executebuiltin('UpdateLocalAddons') 
    #xbmc.executebuiltin('ActivateWindow(10040,addons://outdated/)')   
    #dialog.ok('Update', 'update intiated','','')	
        xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	if plugintools.message_yes_no(AddonTitle, "View Avaliable Updates?"):
		xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/",return)')

elif mode==11:
        ClearAddonData()
elif mode==12:
       launcher(name,url,description)
elif mode==15:
       xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/speedtest.py)')
elif mode==16:
       xbmc.executebuiltin('ActivateWindow(FileManager)')
elif mode==17:
       xbmc.executebuiltin('ActivateWindow(systeminfo)')
elif mode==18:	   
	   loginpro()
   
elif mode==20: #recent movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=trending",return)')
elif mode==21: #recent tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.menu/?folder=TV Shows/Recently Added",return)')
elif mode==22: #new tv shows
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=premiere",return)')
	   #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvmix/?mode=3&url=http%3a%2f%2fwww.watchepisodes1.com%2fhome%2fnew-series",return)')
elif mode==23: #movie years
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieYears",return)')
elif mode==24: #movie genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieGenres",return)')
elif mode==25: #tv genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvGenres",return)')
elif mode==26: #TV Networks
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Networks",return)')
elif mode==27: #movie actors
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=moviePersons",return)')	 
elif mode==29: #boxsets
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.phstreams/?action=directory&url=http://tnpb.offshorepastebin.com/Directories/Movies%20Directories/Boxsets%20Directory.xml",return)')	   
elif mode==30: #search movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.menu/?folder=Movies/Search",return)')
       #xbmc.executebuiltin('ActivateWindow(10000)')
       #quit()
elif mode==31: #search tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.menu/?folder=TV Shows/Search",return)')
       #quit()
elif mode==40: #movies root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies",return)')
elif mode==41: #movies browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies/Browse",return)')	   
elif mode==50: #tv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows",return)')	
elif mode==51: #tv browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows/Browse",return)')
elif mode==60: #livetv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV",return)')
elif mode==61: #livetv providers
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Providers",return)')   
elif mode==62: #livetv News
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=News",return)')
elif mode==63: #livetv Sports
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Sports",return)') 
elif mode==64: #livetv Foregin
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Foregin",return)')
elif mode==65: #livetv Shows
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Shows",return)')
elif mode==70: #search widget
       xbmc.executebuiltin('ActivateWindow(1107)')
elif mode==71: #movies featured
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=featured",return)')
elif mode==72: #movies oscar 
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=oscars",return)')
elif mode==73: #movies popular alltime
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=boxoffice",return)')
elif mode==74: #movies in theaters
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=theaters",return)')
elif mode==75: #movies in theaters
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=theaters",return)')	
elif mode==76: #tvshow  trending
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=trending",return)')
elif mode==77: #tvshow  popular
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=popular",return)')
elif mode==78: #tvshow  popular
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=popular",return)')
elif mode==79: #tvshow  critics
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=rating",return)')
elif mode==80: #tvshow  critics
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=rating",return)')
elif mode==101: #WeatherSettings
	   xbmc.executebuiltin('Addon.OpenSettings(plugin.video.water),return')
	   
if mode==94: #search exodus tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/?action=tvSearch",return)')	   
if mode==95: #search exodus movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/?action=movieSearch",return)') 
if mode==96: 
       	xbmc.executebuiltin('ActivateWindow(10025,"plugin://program.apollo/?action=channels",return)')
if mode==97: 
       	correctPVR ()	   

	   #<favourite name="" thumb="">PlayMedia(&quot;plugin://plugin.video.water/?url=null&mode=19&quot;)</favourite>	   
xbmcplugin.endOfDirectory(int(sys.argv[1]))
