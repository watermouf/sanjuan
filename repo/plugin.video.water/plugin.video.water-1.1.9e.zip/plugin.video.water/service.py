import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2, urllib

path = xbmc.translatePath('special://home/addons/service.galaxyupdate')

installed = xbmc.translatePath("special://home/addons/service.galaxyupdate/installed_version.txt")
latest = xbmc.translatePath("special://home/addons/service.galaxyupdate/latest_version.txt")
#dialog       =  xbmcgui.Dialog()
#dialog.ok("Reminder", "[COLOR yellow]If you haven't turned on your device in a while[/COLOR]", "      Please give KODI 5 minutes to warm up")
def path():
	if not os.path.exists(path):
		os.mkdir(path)

#url = 'http://tiny.cc/buildver'
#urllib.urlretrieve(url, latest)


file_i = open(installed)
file_i.close()

file_l = open(latest, 'r')
checksum_latest = file_l.read()
file_l.close()

def check(checksum):
	datafile = file(installed)
	updated = False
	for line in datafile:
		if checksum in line:
			updated = True
			break
	return updated

def wizard():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
#    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
#    try:    
#        for root, dirs, files in os.walk(temp_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass

#    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
#    try:    
#        for root, dirs, files in os.walk(xbmc_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass


	
	
	
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    try:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass

    axel_cache_path = os.path.join(xbmc.translatePath('special://home/userdata/addon_data/script.module.axel.downloader'), '')
    try:    
        for root, dirs, files in os.walk(axel_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
    allinone_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.allinone/icons'), '')
    try:    
        for root, dirs, files in os.walk(allinone_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    ccloud_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.ccloud/resources/icons'), '')
    try:    
        for root, dirs, files in os.walk(ccloud_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    vidtime_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.VidTime/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(vidtime_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    castaway_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.castaway/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(castaway_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass    
	
    sportsdevil_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.SportsDevil/resources/images/'), '')
    try:    
        for root, dirs, files in os.walk(sportsdevil_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
if check(checksum_latest):
	wizard()
else:
	wizard()
