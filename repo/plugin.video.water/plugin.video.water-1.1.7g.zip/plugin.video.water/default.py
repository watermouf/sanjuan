import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
#from addon.common.addon import Addon
from addon.common.addon import Addon
#from addon.common.net import Net
from addon.common.net import Net
import ntpath
import zipfile
import speedtest
import socket   
#import webbrowser
#from t0mm0.common.net import Net as net
  
base='http://repo.none.com/repo'  
VERSION = "1.0.0"
PATH = "WaterTV"   
AddonTitle="WaterTV"
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.water'
AddonID='plugin.video.water'
ADDON = xbmcaddon.Addon(id=addon_id)
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "0.0.1"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "WaterTV"            
BASEURL = "http://tiny.cc.com"
H = 'http://'
EXCLUDES     = ['skin.confluence','plugin.video.water','weather.yahoo','metadata.album.universal','metadata.common.allmusic.com','metadata.common.fanart.tv','metadata.common.htbackdrops.com','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.common.theaudiodb.com','metadata.common.themoviedb.org','metadata.musicvideos.theaudiodb.com','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck','metadata.artists.universal','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','metadata.themoviedb.org','script.module.addon.common','packages','system','cache'] #EXPERMINATAL CACHE AND SYSTEM ADD IN AT END OF SCRIPT IF SUCCESSFULL
EXCLUDES2     = ['media','userdata','plugin.program.super.favourites','plugin.program.video.node.editor','plugin.program.water.notifications','plugin.stream.vaughnlive.tv','plugin.video.1channel','plugin.video.allinone','plugin.video.castaway','plugin.video.ccloudtv','plugin.video.DecadoDocs','plugin.video.documentarytube','plugin.video.funniermoments','plugin.video.historytube','plugin.video.israelive','plugin.video.origin2','plugin.video.pftvso','plugin.video.phstreams','plugin.video.smithsonian','plugin.video.SportsDevil','plugin.video.tgun','plugin.video.ustvvod','plugin.video.veetle','plugin.video.water','plugin.video.youtube','plugin.video.yt-crime','repo.water','repo.water.3rdparty','repository.aresproject','repository.awesome','repository.BlazeRepo','repository.chrischrome','repository.coldkeys','repository.dnarepo','repository.dudehere.plugins','repository.eldorado','repository.entertainmentrepo','repository.exodus','repository.GenieTv','repository.HalowTV','repository.husham.com','repository.istream','repository.Kinkin','repository.kodil','repository.lambda','repository.legends','repository.lunatixz','repository.mdrepo','repository.megatron','repository.metalkettle','repository.natko1412''repository.pipcan','repository.podgod','repository.schismtv.addons','repository.schismtv.addonsdev','repository.shani','repository.spoyser','repository.t1m','repository.The_Silencer','repository.tknorris.beta','repository.tva.common','repository.VinManJSV','repository.xbmc-israel','repository.xbmc.org','repository.xbmchub','repository.xbmcplus.xbmc','repository.xunitytalk','resource.language.en_gb','resource.language.en_us','script.autoruns','script.common.plugin.cache','script.extendedinfo','script.favourites','script.ftvguide','script.module.addon.common','script.module.addon.signals','script.module.axel.downloader','script.module.beautifulsoup','script.module.beautifulsoup4','script.module.coveapi','script.module.cssutils','script.module.dnspython','script.module.elementtree','script.module.free.cable.database','script.module.html5lib','script.module.httplib2','script.module.israeliveresolver','script.module.liveresolver','script.module.mechanize','script.module.metahandler','script.module.myconnpy','script.module.parsedom','script.module.pyamf','script.module.pycaption','script.module.pyxbmct','script.module.requests','script.module.simple.downloader','script.module.simplejson','script.module.six','script.module.socksipy','script.module.stem','script.module.t0mm0.common','script.module.t1mlib','script.module.TheYid.common','script.module.urlresolver','script.module.youtube.dl','script.supafav','service.galaxyupdate','service.library.data.provider','service.subtitles.opensubtitles','service.xbmc.versioncheck','skin.water2','skin.confluence','superrepo.kodi.isengard.all','weather.yahoo','script.skinshortcuts','metadata.album.universal','metadata.common.allmusic.com','metadata.common.fanart.tv','metadata.common.htbackdrops.com','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.common.theaudiodb.com','metadata.common.themoviedb.org','metadata.musicvideos.theaudiodb.com','metadata.themoviedb.org','metadata.tvdb.com','service.library.data.provider','service.xbmc.versioncheck','metadata.artists.universal','metadata.musicvideos.theaudiodb.com','metadata.common.imdb.com','metadata.themoviedb.org']
addon_id        = 'plugin.video.water'
ADDON           = xbmcaddon.Addon(id=addon_id)
selfAddon       = xbmcaddon.Addon(id=addon_id)
datapath        = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
user            = selfAddon.getSetting('wusername')
passw           = selfAddon.getSetting('wpassword')
cookie_file     = os.path.join(os.path.join(datapath,''), 'water.lwp')


#socket.setdefaulttimeout(60)
#if user == '' or passw == '':
#    if os.path.exists(cookie_file):
#        try: os.remove(cookie_file)
#        except: pass
#    dialog = xbmcgui.Dialog()
#    ret = dialog.yesno('Update 2.0', 'Please enter your assigned username and password','If you dont have these check your emails','Or contact support for further instructions','Cancel','Login')
#    if ret == 1:
#        keyb = xbmc.Keyboard('', 'Enter Username')
#        keyb.doModal()
#        if (keyb.isConfirmed()):
#            search = keyb.getText()
#            username=search
#            keyb = xbmc.Keyboard('', 'Enter Password:')
#            keyb.doModal()
#            if (keyb.isConfirmed()):
#                search = keyb.getText()
#                password=search
#                selfAddon.setSetting('wusername',username)
#                selfAddon.setSetting('wpassword',password)
#user = selfAddon.getSetting('wusername')
#passw = selfAddon.getSetting('wpassword')
#domid = 'http://water.esy.es'


def CATEGORIES_PRO():
    setCookie(domid+'/amember/member')
    response = net().http_GET(domid+'/amember/member')
    if not 'Logged in as' in response.content:
        dialog = xbmcgui.Dialog()
        dialog.ok('Update 2.0', 'An error has ocurred logging in','Please check your details in addon settings','')
        quit()
    link = OPEN_URL(domid+'/amember/content/f/id/1/').replace('\n','').replace('\r','')
    print link
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def INDEX():
    link = OPEN_URL('http://tiny.cc/wizardtxt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
	addDir(name,url,1,iconimage,fanart,description)
    addDir('Web Browser',BASEURL,9,'http://findicons.com/files/icons/1715/gion/128/internet_web_browser.png',FANART,'')
    addDir('File Manager',BASEURL,16,'http://files.softicons.com/download/system-icons/crystal-project-icons-by-everaldo-coelho/png/256x256/apps/file-manager.png',FANART,'')	
    addDir('System Info',BASEURL,17,'http://findicons.com/files/icons/1261/sticker_system/256/get_info.png',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://cdn.appstorm.net/iphone.appstorm.net/files/2011/02/SpeedTest-Icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'')
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')	
    #addDir('DONATE',BASEURL,3,ART+'donate.jpg',FANART,'') 
    #addDir('waterS BUILD',url,4,ART+'icon.png',FANART,'')
    setView('movies', 'MAIN')


def wizard(name,url,description): 
    dp = xbmcgui.DialogProgress()
    dp.create("WaterTV","Clearing Cache", 'Please Wait','')
    #SILENTFRESH(params)
    ClearAddonData()
    xbmc.sleep(5000)
    dp.update(0,"", "Downloading Update Please Wait")
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    #dp.create("WaterTV","Downloading Update", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    ClearJunk()
    killxbmc()

	
def BUILDMENU():
    addDir('Fresh Start',BASEURL,6,'http://vignette1.wikia.nocookie.net/scream-queens/images/8/88/Update-icon.png/revision/latest?cb=20150927230935',FANART,'') 
    setView('movies', 'MAIN')
	
def MAINTENANCE():
    #addDir('DELETE CACHE','url',4,ART+'deletecache.png',FANART,'')
    #addDir('IVUE TV GUIDE RESET','url',11,ART+'reset.jpg',FANART,'')
    #addDir('FRESH START','url',6,ART+'freshstart.jpg',FANART,'')
    #addDir('DELETE PACKAGES','url',7,ART+'deletepackages.jpg',FANART,'')
    addDir('SpeedTest',BASEURL,15,'http://icons.iconarchive.com/icons/chrisbanks2/cold-fusion-hd/128/speed-test-icon.png',FANART,'') 
    addDir('Fresh Start',BASEURL,6,'http://icons.iconarchive.com/icons/mazenl77/I-like-buttons-3a/512/Perspective-Button-Shutdown-icon.png',FANART,'') 
    addDir('MORE TOOLS',BASEURL,8,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    addDir('MORE TOOLS2',BASEURL,3,'http://b.dryicons.com/images/icon_sets/coquette_part_7_icons_set/png/128x128/toolbox.png',FANART,'')
    setView('movies', 'MAIN')
    setView('movies', 'MAIN')
	
def armdownlr(name,url,description):
    confirm=xbmcgui.Dialog()
    if confirm.yesno(name,description,"","","Back","Download"):
        dp = xbmcgui.DialogProgress()
        dp.create("Download","Downloading...",name,'')
        lib = xbmc.translatePath(os.path.join('sdcard','Download',name +'.apk'))
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)
        time.sleep(1)
        dialog.ok("Installation instructions","1) Exit Kodi 2) Open Android file manager","3) Navigate to Download folder","4) Click on APK file to install")
	
	
def wizard2(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    dontkillxbmc()
	
	
def wizard3(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    #dp = xbmcgui.DialogProgress()
    #dp.create("UPDATE","Update Downloading ", 'Please Wait','')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp = xbmcgui.DialogProgress()
    dp.create(0,"", "Installing Update Please Wait")
    extract.all(lib,addonfolder,dp)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    dontkillxbmc()	
#################################
####### POPUP TEXT BOXES ########
#################################

def setCookie(srDomain):
    html = net().http_GET(srDomain).content
    r = re.findall(r'<input type="hidden" name="(.+?)" value="(.+?)" />', html, re.I)
    post_data = {}
    post_data['amember_login'] = user
    post_data['amember_pass'] = passw
    for name, value in r:
        post_data[name] = value
    net().http_GET(domid+'/amember/member')
    net().http_POST(domid+'/amember/member',post_data)
    net().save_cookies(cookie_file)
    net().set_cookies(cookie_file)

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes('WaterTV', 'TEST')

def donation():
    TextBoxes('WaterTV', 'TEST')
    
def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("WaterTV", "Packages Successfuly Removed")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("WaterTV", "Sorry we were not able to remove Package Files", "[COLOR yellow]:([/COLOR]")			
	
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
                
    # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("WaterTV", " All Cache Files Removed", "[COLOR yellow]![/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################
def dontkillxbmc():
  dialog = xbmcgui.Dialog() 
  dialog.ok('Update', 'All Done','') 
  quit()
  
def ClearAddonData():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES]
            #file_count = 0
            #file_count += len(files)
        # Count files and give option to delete
            #if file_count > 0: 
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
               shutil.rmtree(os.path.join(root, d))
    except: 
		pass

    packages_cache_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
	    dirs[:] = [d for d in dirs if d not in EXCLUDES]
            #file_count = 0
            #file_count += len(files)
        # Count files and give option to delete
            #if file_count > 0: 
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
               shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
def ClearJunk():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
#    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
#    try:    
#        for root, dirs, files in os.walk(temp_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass
    axel_cache_path = os.path.join(xbmc.translatePath('special://home/userdata/addon_data/script.module.axel.downloader'), '')
    try:    
        for root, dirs, files in os.walk(axel_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
    allinone_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.allinone/icons'), '')
    try:    
        for root, dirs, files in os.walk(allinone_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    ccloud_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.ccloud/resources/icons'), '')
    try:    
        for root, dirs, files in os.walk(ccloud_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    vidtime_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.VidTime/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(vidtime_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    castaway_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.castaway/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(castaway_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass

def killxbmc():		
    dialog.ok("IMPORTANT", "If Kodi does [COLOR red][B]NOT[/B][/COLOR] close after you click [COLOR yellow]OK[/COLOR]", "[B]YOU MUST PULL THE [COLOR red]POWER[/COLOR] ON YOUR DEVICE[/B]",'')
    #if choice == 1:
    #    return
    #elif choice == 0:
    #    pass
 			

    

    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass    
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")
	killxbmc()
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
		
def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with WaterTV, Please Restart Kodi and go to Programs / WaterTV")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kodi configuration with WaterTV, Please Restart Kodi and go to Programs / WaterTV")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Please Restart Kodi and go to Programs / WaterTV",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)

	
def SILENTFRESH(params):
    addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
    xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
    try:
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                except:
                    if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
            for name in dirs:
                try: os.rmdir(os.path.join(root,name)) 
                #shutil.rmtree(os.path.join(root, name))
                except: pass
	for name in dirs:
                #try: os.rmdir(os.path.join(root,name)) 
                try: shutil.rmtree(os.path.join(root, name))
                except: pass	
	for name in files:
	    #try: os.remove(os.path.join(root,name)) 
                #try: os.unlink(os.path.join(root, name)))
                os.remove(os.path.join(root,name))

    except: pass 
				
def REFRESH(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to refresh your","system?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=addon_id).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES2]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"Your system has been refreshed")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"Your system has been refreshed")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Please Restart Kodi and go to Programs / WaterTV",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()
elif mode==1:
        wizard(name,url,description)
		
elif mode==2:
        #BUILDMENU()
		CATEGORIES()

elif mode==3:
    #facebook()
	armdownlr(name,url,description)
		
elif mode==4:
        BUILDMENU()
		
elif mode==5:
        wizard2(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       DeletePackages(url)		
elif mode==8:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=More/Settings/Maintenance/More Tools",return)')
elif mode==9:
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/webbrowser.py)')
elif mode==10:
    #deletecachefiles(url)
    xbmc.executebuiltin('UpdateAddonRepos') 
    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin('ActivateWindow(10040,addons://outdated/)')     
elif mode==15:
       xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.water/speedtest.py)')
elif mode==16:
       xbmc.executebuiltin('ActivateWindow(FileManager)')
elif mode==17:
       xbmc.executebuiltin('ActivateWindow(systeminfo)')
elif mode==18:	   
	   loginpro()
elif mode==20: #recent movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movies&url=trending",return)')
elif mode==21: #recent tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Recently Added",return)')
elif mode==22: #new tv shows
       #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvshows&url=premiere",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvmix/?mode=3&url=http%3a%2f%2fwww.watchepisodes1.com%2fhome%2fnew-series",return)')
elif mode==23: #movie years
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieYears",return)')
elif mode==24: #movie genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=movieGenres",return)')
elif mode==25: #tv genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=tvGenres",return)')
elif mode==26: #TV Networks
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/TV onDemand",return)')
elif mode==27: #movie actors
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.origin2/?action=moviePersons",return)')	 
elif mode==29: #boxsets
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.phstreams/?action=directory&url=http://tnpb.offshorepastebin.com/Directories/Movies%20Directories/Boxsets%20Directory.xml",return)')	   
elif mode==30: #search movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies/Search",return)')
elif mode==31: #search tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Search",return)')	   
#<favourite name="" thumb="">PlayMedia(&quot;plugin://plugin.video.water/?url=null&amp;mode=19&quot;)</favourite>	   
xbmcplugin.endOfDirectory(int(sys.argv[1]))
