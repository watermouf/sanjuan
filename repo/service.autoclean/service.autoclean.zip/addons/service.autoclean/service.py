import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2, urllib


def clear():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
#    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
#    try:    
#        for root, dirs, files in os.walk(temp_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass

#    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
#    try:    
#        for root, dirs, files in os.walk(xbmc_cache_path):
#            file_count = 0
#            file_count += len(files)
#        # Count files and give option to delete
#            if file_count > 0: 
#                    for f in files:
#                        os.unlink(os.path.join(root, f))
#                    for d in dirs:
#                       shutil.rmtree(os.path.join(root, d))
#    except: 
#		pass


	
	
	
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    try:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass

    axel_cache_path = os.path.join(xbmc.translatePath('special://home/userdata/addon_data/script.module.axel.downloader'), '')
    try:    
        for root, dirs, files in os.walk(axel_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
    allinone_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.allinone/icons'), '')
    try:    
        for root, dirs, files in os.walk(allinone_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    ccloud_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.ccloud/resources/icons'), '')
    try:    
        for root, dirs, files in os.walk(ccloud_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    vidtime_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.VidTime/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(vidtime_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass 
    castaway_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.castaway/resources/media/'), '')
    try:    
        for root, dirs, files in os.walk(castaway_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass    
	
    sportsdevil_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.SportsDevil/resources/images/'), '')
    try:    
        for root, dirs, files in os.walk(sportsdevil_icon_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass    

    #teevee_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.teevee/resources/media/'), '')
    #try:    
    #    for root, dirs, files in os.walk(teevee_icon_path):
    #        file_count = 0
    #        file_count += len(files)
    #    # Count files and give option to delete
    #        if file_count > 0: 
    #                for f in files:
    #                    os.unlink(os.path.join(root, f))
    #                for d in dirs:
    #                   shutil.rmtree(os.path.join(root, d))
    #except: 
	#	pass


		
def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

databasePath = xbmc.translatePath('special://userdata/Database')
thumbnailPath = xbmc.translatePath('special://userdata/Thumbnails');
THUMBS     =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))	
THUMBS_TO_CLEAR = 40000000
THUMBS_SIZE_BYTE    = get_size(THUMBS)

def AUTO_CLEAR_THUMBS_MB():

    if os.path.exists(thumbnailPath)==True:  
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
								pass
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    try:
		os.unlink(text13)
    except OSError:
        pass
		
clear()
if THUMBS_SIZE_BYTE > THUMBS_TO_CLEAR:
			AUTO_CLEAR_THUMBS_MB()		
weatheraddon    = xbmcaddon.Addon(id='weather.yahoo')
dialog          = xbmcgui.Dialog()
zipcode         = weatheraddon.getSetting('Location1')
if weatheraddon.getSetting('Location1') == '':
    ret = dialog.yesno('Weather', 'Please enter your zip code to set weather','',"",'Cancel','Set Weather')
    if ret == 1:
        xbmc.executebuiltin('Addon.OpenSettings(weather.yahoo),return')
        xbmc.executebuiltin('Weather.Refresh')
		
		

#if xbmcaddon.Addon(id='plugin.video.keyword').getSetting('keyword') == 'test':
#    ret = dialog.yesno('waterTV', 'Please enter your zip code to set weather','',"",'Cancel','Set Weather')
#    if ret == 1:
#        xbmc.executebuiltin('Addon.OpenSettings(weather.yahoo),return')
#        xbmc.executebuiltin('Weather.Refresh')		  