import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2, urllib

def clear(pathtoclear):
    packages_cache_path = xbmc.translatePath(os.path.join(pathtoclear, ''))
    try:    
        for root, dirs, files in os.walk(''+packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0: 
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                       shutil.rmtree(os.path.join(root, d))
    except: 
		pass
		
def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

databasePath = xbmc.translatePath('special://userdata/Database')
thumbnailPath = xbmc.translatePath('special://userdata/Thumbnails');
THUMBS     =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))	
THUMBS_TO_CLEAR = 40000000
THUMBS_SIZE_BYTE    = get_size(THUMBS)

def AUTO_CLEAR_THUMBS_MB():

    if os.path.exists(thumbnailPath)==True:  
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
								pass
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    try:
		os.unlink(text13)
    except OSError:
        pass
		
clear('special://home/addons/packages')
clear('special://home/addons/plugin.video.ccloud/resources/icons')
clear('special://home/temp')
clear('special://home/cache')
clear('special://profile/addon_data/script.module.simple.downloader')
clear('special://home/userdata/addon_data/script.module.axel.downloader')
clear('special://home/addons/plugin.video.SportsDevil/resources/images/')

clear('special://home/addons/repository.entertainmentrepo/')
clear('special://home/addons/repository.natko1412/')
clear('special://home/addons/repository.xbmcplus.xbmc/')
clear('special://home/addons/repository.GearsTV/')
clear('special://home/addons/repository.M-TVGuide/')
clear('special://home/addons/repository.VinManJSV/')
clear('special://home/addons/repository.Kinkin/')

clear('special://home/addons/plugin.program.mtvguide/')
clear('special://home/addons/plugin.video.VidTime/')

if THUMBS_SIZE_BYTE > THUMBS_TO_CLEAR:
			AUTO_CLEAR_THUMBS_MB()		

