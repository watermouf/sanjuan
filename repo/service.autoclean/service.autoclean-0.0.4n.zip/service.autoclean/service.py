import os, re, shutil, time, xbmc
try:
	import json as simplejson 
except:
	import simplejson

#file = xbmc.translatePath('special://home/addons/service.openeleq/guisettings.xml')
path = xbmc.translatePath('special://home/addons/service.water')
#zip = xbmc.translatePath('special://home/addons/packages/Quix.zip')
servicepy = xbmc.translatePath('special://home/addons/service.water/service.py')

#false list ? 
#bflist = ["DisableGlobalSearch","HomepageHideRecentlyAddedVideo","HomepageHideRecentlyAddedAlbums","UseCustomBackground","UseCustomBackgroundFolder","HideBackGroundFanart","ShowBackgroundVideo","ShowBackgroundVis","SkinMod","KidsProfile","homepageMusicinfo","homepageVideoinfo","HomeMenuNoMovieButton","HomeMenuNoTVShowButton","HomeMenuNoWeatherButton","HomeMenuNoCustomHomeButton1","HomeMenuNoPicturesButton","HomeMenuNoCustomHomeButton2","HomeMenuNoRadioButton","HomeMenuNoCustomHomeButton3","HomeMenuNoTVButton","HomeMenuNoCustomHomeButton4","HomeMenuNoVideosButton","HomeMenuNoCustomHomeButton5","HomeMenuNoCustomHomeButton6","HomeMenuNoCustomHomeButton7","HomeMenuMusicVideosButton","HomeMenuNoCustomHomeButton8","HomeMenuNoMusicButton","HomeMenuNoCustomHomeButton9","HomeMenuNoProgramsButton","HomeMenuNoCustomHomeButton10","HomeMenuNoDVDButton","HomeMenuNoSystemButton","Favourite1","Favourite2","Favourite3","Favourite4","Favourite5","Favourite6","Favourite7","Favourite11","Favourite12","Favourite13","Favourite14","Favourite15","Favourite16","Favourite17","Favourite21","Favourite22","Favourite23","Favourite24","Favourite25","Favourite26","Favourite27","Favourite31","Favourite32","Favourite33","Favourite34","Favourite35","Favourite36","Favourite37","HideFilenameFlagging","View508HideInfo","ActivateTvTunes","XXX","SuperShortcuts","Show_SlideShow_Paused","WindowedTrailer","Use_Startup_Playlist","AutoSubSearch","DeveloperMode","EnableDeveloper","HideVisualizationFanart","kioskmode","AnimeWindowXMLDialogClose","FavouriteVideoAddons","FavouriteMusicAddons","FavouritePictureAddons"]

bflist = ["DisableFloorBtns"]
#true list ?
#blist = ["MusicFullscreen","homepageWeatherinfo","SystemDate","SystemWeatherinfo","AutoScroll","FirstTimeRun","ArtistSlideshow","SkinMod"]
btlist = ["HideHomeFloor","LowerMainMenuBar", "HideTopLeftWindows", "AllScreenTopLeftWidget", "HidePageCountInfo","DisableGlobalSearch", "SingleGlobalBackground", "HideBackGroundFanart", "InitialSetUpRun"]
# variable


moviemenu = ["HomeItem.1.Widget|plugin://plugin.video.origin2/?action=channels","HomeItem.1.Label|Movies","HomeItem.1.type|Movies","HomeItem.1.sub|Movies","HomeItem.1.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=40&url=null"",return)",          "SubMovies.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubMovies.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=20"",return)",       "SubMovies.2.Label|By [B][COLOR white]Year[/COLOR][/B]","SubMovies.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=23"",return)",        "SubMovies.3.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubMovies.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=24"",return)",           "SubMovies.4.Label|By [B][COLOR white]Actors[/COLOR][/B]","SubMovies.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=27"",return)",           "SubMovies.5.Label|[B][COLOR white]Search [COLOR steelblue]Movies[/COLOR][/B]","SubMovies.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=30"",return)",           "SubMovies.6.Label|Hidden","SubMovies.6.Path|Hidden","SubMovies.7.Label|Hidden","SubMovies.7.Path|Hidden",       "AddonSetOne.1.Path|ActivateWindow(10025,""plugin://plugin.video.origin2/?action=movies&url=http%3A%2F%2Fwww.imdb.com%2Flist%2Fls066339531"" ,return)", "HomeItem.1.Addon|AddonSetOne", "AddonSetOne.1.label|Thanksgiving", "AddonSetOne.1.Icon|http://4vector.com/i/free-vector-thanksgiving-day-icon_102047_Thanksgiving_Day_Icon.png", "AddonSetOne.2.Path|","AddonSetOne.4.Path|", "AddonSetOne.2.label|", "AddonSetOne.2.Icon|",]

tvmenu = ["HomeItem.2.Widget|plugin://plugin.program.super.favourites/?label=nul&amode=400&folder=TV%20shows%2FTV%20onDemand", "HomeItem.2.Label|TV Shows","HomeItem.2.sub|TVShows","HomeItem.2.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=50&url=null"",return)",          "SubTVShows.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubTVShows.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=21"",return)",          "SubTVShows.2.Label|[B][COLOR white]New[/COLOR][/B] Shows","SubTVShows.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=22"",return)",        "SubTVShows.4.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubTVShows.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=25"",return)",          "SubTVShows.3.Label|[B]By [COLOR white]Network[/COLOR][/B]","SubTVShows.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=26"",return)",        "SubTVShows.5.Label|[B][COLOR white]Search[/COLOR] [COLOR steelblue]TV[/COLOR][/B]","SubTVShows.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=31"",return)"]

livemenu = ["HomeItem.3.Widget|plugin://plugin.video.ustvnow.tva/?mode=live","HomeItem.3.Label|Live TV","HomeItem.3.type|Movies","HomeItem.3.Addon|AddonSetThree","HomeItem.3.sub|LiveTV","HomeItem.3.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=60&url=null"",return)",          "SubLiveTV.1.Label|[B]N[COLOR white]ews[/COLOR][/B]","SubLiveTV.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=62"",return)",          "SubLiveTV.2.Label|[B]S[COLOR white]ports[/COLOR][/B]","SubLiveTV.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=63"",return)",        "SubLiveTV.3.Label|[B]S[COLOR white]hows[/COLOR][/B]","SubLiveTV.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=65"",return)",          "SubLiveTV.4.Label|[B]F[COLOR white]oreign[/COLOR][/B]","SubLiveTV.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=64"",return)",        "SubLiveTV.5.Label|Hidden","SubLiveTV.5.Path|Hidden","SubLiveTV.6.Label|Hidden","SubLiveTV.6.Path|Hidden","SubLiveTV.7.Label|Hidden","SubLiveTV.7.Path|Hidden","SubLiveTV.9.Label|Hidden","SubLiveTV.9.Path|Hidden","AddonSetThree.1.label|TV Guide","AddonSetThree.1.Path|RunScript(script.waterguide,return)", "AddonSetThree.1.Icon|http://rocketdock.com/images/screenshots/TV-Guide.png"]

moremenu = ["HomeItem.4.Label|[COLOR steelblue]M[/COLOR]ORE","HomeItem.4.Widget|Weather", "HomeItem.4.type|System", "HomeItem.4.Addon|AddonSetTwelve", "HomeItem.4.sub|Settings","HomeItem.4.path|ActivateWindow(Settings))", "HomeItem.4.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=more"",return)",         "SubSettings.1.Label|[B]S[COLOR white]ettings[/COLOR][/B]","SubSettings.1.Path|ActivateWindow(Settings)", "SubSettings.2.Path|Hidden", "SubSettings.3.Path|Hidden", "SubSettings.4.Path|Hidden", "SubSettings.5.Path|Hidden", "SubSettings.6.Path|Hidden",      "AddonSetTwelve.1.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/"" ,return)", "AddonSetTwelve.1.label|YouTube", "AddonSetTwelve.1.Icon|http://www.usacapitol.com/SiteAssets/stay-connected/youtube-logo.png",                  "AddonSetTwelve.2.label|Music", "AddonSetTwelve.2.Icon|",                     "AddonSetTwelve.4.label|KidsTV", "AddonSetTwelve.4.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/KidsTV"",return)", "AddonSetTwelve.4.Icon|http://icons.iconarchive.com/icons/martin-berube/people/256/kid-icon.png" ,     "AddonSetTwelve.3.label|Documentaries","AddonSetTwelve.3.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/Documentaries"",return)", "AddonSetTwelve.3.Icon|https://solutionsmedia.cbcrc.ca/Pictures/chaineslogos/CBC_documentary_blanc_15.png", "AddonSetTwelve.3.Icon|http://www.filmsite.org/images/documentary-genre.jpg",  "AddonSetTwelve.5.label|Stand-Up","AddonSetTwelve.5.Path|ActivateWindow(10025,""plugin://plugin.video.phstreams/?action=directory&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fStandup.xml"",return)", "AddonSetTwelve.5.Icon|https://lh6.ggpht.com/JH8vf9T54XQET1h-BgpvZrXedGkWEqG-K9DSgf_TXlU2r0WpM3NlZ817a3F9Ch83aBg=w150","AddonSetTwelve.6.Path|", ]

hiddenmenu = ["GlobalBackgroundPath|special://home/addons/script.supafav/BG/","TopLeftHomeInfo|Weather","HomeItem.5.path|","HomeItem.6.path|","HomeItem.7.path|","HomeItem.8.path|","HomeItem.9.path|","HomeItem.10.path|","HomeItem.11.path|","HomeItem.12.path|","PowerBtnAction|Exit"]




def read_from_file(path, silent=False):
	try:
		f = open(path, 'r')
		r = f.read()
		f.close()
		return str(r)
	except:
		return None

def getSetting(setting):
	try:
		setting = '"%s"' % setting 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None

def setSetting(setting, value):
	setting = '"%s"' % setting
	value = '"%s"' % value
	query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
	response = xbmc.executeJSONRPC(query)


if __name__ == '__main__':
	xbmc.executebuiltin("ActivateWindow(Home)")
	setting = 'lookandfeel.skin'
	value = 'skin.water2'
	current = getSetting(setting)
	setSetting(setting, value)
	while current != 'skin.water2':
		xbmc.executebuiltin("Action(Select)")
		current = getSetting(setting)
	for item in bflist:
		xbmc.executebuiltin("Skin.Reset("+item+")")
	for item in btlist:
		xbmc.executebuiltin("Skin.SetBool("+item+")")
	for item in moviemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in tvmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in livemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in moremenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in hiddenmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	#shutil.rmtree(path)
	#os.remove(servicepy)
	time.sleep(1)
	xbmc.executebuiltin("Notification(wtv,Enjoy!,5000,https://lh6.ggpht.com/dL9--GgOGLaQxycrYCgvyyxU-dn6L9_eHf73Exwm_D8_1aciSfGEFCxcMs6jRc-hmf4c=w300)")
	#setting = 'lookandfeel.skin'
	#value = 'skin.water2'
	#current = getSetting(setting)
	#setSetting(setting, value)

#backup trakt		



		
import xbmc, xbmcgui, shutil, urllib2, urllib, os, xbmcaddon, zipfile, time
#backup trakt	
if not xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') == '': 
        otrakt_user = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') 
	otrakt_token = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.token')
	otrakt_refresh = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.refresh')
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.user',otrakt_user)
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.token',otrakt_token)
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.refresh',otrakt_refresh)    

#if not xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_user') == '': 
#	strakt_user = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_user')
#	strakt_token = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_oauth_token')
#	strakt_refresh = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_refresh_token') 
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.user',strakt_user)
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.token',strakt_token)
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.refresh',strakt_refresh)
#
addon = xbmcaddon.Addon('service.autoclean')
url        = 'https://raw.githubusercontent.com/watermouf/sanjuan/master/repo/service.autoclean/service.autoclean.zip'
path       = xbmc.translatePath('special://home/addons/packages')
lib        = xbmc.translatePath(os.path.join(path,'autoclean.zip'))
home       = xbmc.translatePath('special://home')
profile    = 'Master user'
lock       = 'false'
localtxt00 = 'AutoClean Installer'
localtxt01 = 'Install'
localtxt02 = 'Downloading. Please Wait.'
localtxt03 = 'Downloaded: '
localtxt04 = 'Download Cancelled.'
localtxt05 = 'Updating'
localtxt06 = 'Succeeded'
localtxt07 = 'Installing. Please Wait.'

def DownloaderClass(url,dest):
	dp = xbmcgui.DialogProgress()
	dp.create(localtxt00,localtxt02,'')
	urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*100)/filesize, 100)
		print localtxt03+str(percent)+'%'
		dp.update(percent)
	except:
		percent = 100
		dp.update(percent)
	#if dp.iscanceled(): 
		#raise Exception("Cancelled")
		#dp.close()

def ExtractorClass(_in, _out):
	dp = xbmcgui.DialogProgress()
	dp.create(localtxt00,localtxt07,'')
	zin    = zipfile.ZipFile(_in,  'r')
	nFiles = float(len(zin.infolist()))
	count  = 0
	for item in zin.infolist():
		count += 1
		update = count / nFiles * 100
		zin.extract(item, _out)

if __name__ == '__main__':
	dialog = xbmcgui.Dialog()
	try:
		DownloaderClass(url,lib)
	except:
		xbmc.executebuiltin('Notification(Download Failed,Please Try Again Later,50000,special://skin/icon.png)')
	time.sleep(1)
	try:
		ExtractorClass(lib,home)
	except:
		xbmc.executebuiltin('Notification(Unpacking Failed,Please Try Again Later,50000,special://skin/icon.png)')
	time.sleep(1)
	#xbmc.executebuiltin('UpdateLocalAddons')
	#xbmc.executebuiltin('UpdateAddonRepos')
	#xbmc.executebuiltin('RunScript(service.installer)')
	#restore trakt		

xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.user',otrakt_user)
xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.token',otrakt_token)
xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.refresh',otrakt_refresh)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_user',strakt_user)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_oauth_token',strakt_token)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_refresh_token',strakt_refresh)  

	
#if xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') == '':
    #if not xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt.user') == '':
        #otrakt_user = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.user')
        #otrakt_token = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.token')
        #otrakt_refresh = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.refresh')
		
     
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.user','')
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.token','')
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.refresh','')
		
#if xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt.user') == '':
    #if not xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt.user') == '':	
	        #strakt_user = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('strakt_user')
	        #strakt_token = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('strakt_oauth_token')
	        #strakt_refresh = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt_refresh_token') 

			
