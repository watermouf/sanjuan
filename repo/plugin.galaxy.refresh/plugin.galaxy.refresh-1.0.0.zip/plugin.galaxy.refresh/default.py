#------------------------------------------------------------
# Fresh Start # - XBMCHUB.com - TVADDONS.ag - #
#------------------------------------------------------------
# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for restoring XBMC to its default settings.
# Version 1.0.1
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#------------------------------------------------------------
AddonID='plugin.galaxy.refresh'; AddonTitle="refresh"
import os,sys,plugintools,xbmcaddon
EXCLUDES     = ['menu.galaxy.platform','plugin.program.video.node.editor','plugin.stream.vaughnlive.tv','plugin.video.1channel','plugin.video.phstreams','plugin.video.salts','plugin.video.smithsonian','plugin.video.SportsDevil','plugin.video.ustvvod','plugin.video.veetle','plugin.video.vevo','plugin.video.water','plugin.video.youtube','pluging.video.stalkerforever-master','repo.water','repo.water.3rdparty','repository.aresproject','repository.BlazeRepo','repository.dnarepo','repository.dudehere.plugins','repository.eldorado','repository.entertainmentrepo','repository.exodus','repository.GenieTv','repository.HalowTV','repository.husham.com','repository.istream','repository.Kinkin','repository.kodil','repository.kodilover','repository.lambda','repository.legends','repository.lunatixz','repository.mdrepo','repository.megatron','repository.metalkettle','repository.natko1412','repository.noobsandnerds','repository.OperationRobocop','repository.podgod','repository.schismtv.addons','repository.schismtv.addonsdev','repository.shani','repository.spoyser','repository.t1m','repository.team.expat','repository.tknorris.beta','repository.tva.common','repository.VinManJSV','repository.xbmc-israel','repository.xbmc.org','repository.xbmchub','repository.xbmcplus.xbmc','repository.xunitytalk','resource.language.en_us','script.autoruns','script.common.plugin.cache','script.extendedinfo','script.favourites','script.ftvguide','script.module.addon.common','script.module.addon.signals','script.module.axel.downloader','script.module.beautifulsoup','script.module.beautifulsoup4','script.module.coveapi','script.module.cssutils','script.module.dnspython','script.module.elementtree','script.module.free.cable.database','script.module.html5lib','script.module.httplib2','script.module.metahandler','script.module.myconnpy','script.module.parsedom','script.module.pyamf','script.module.pycaption','script.module.pyxbmct','script.module.requests','script.module.simple.downloader','script.module.simplejson','script.module.six','script.module.socksipy','script.module.stem','script.module.t0mm0.common','script.module.t1mlib','script.module.urlresolver','script.module.youtube.dl','script.supafav','script.watertvguide','script.watertvguide.kids','script.watertvguide.news','script.watertvguide.ppv','script.watertvguide.sports','service.galaxyupdate','service.library.data.provider','service.subtitles.opensubtitles','service.xbmc.versioncheck','skin.water2','superrepo.kodi.isengard.all','weather.yahoo','plugin.program.super.favourites','plugin.program.water.notifications','plugin.video.castaway','plugin.video.hulubox','plugin.video.israelive','plugin.video.md9movies','plugin.video.mdpubfilm','plugin.video.mdwatchtvseries','plugin.video.movienight','plugin.video.origin2','plugin.video.pftvso','plugin.video.phstreams','plugin.video.playlistLoader''plugin.video.ustvvod','plugin.video.velocity','plugin.video.watch1080','plugin.video.xmovies8','plugin.video.youtube','pluging.video.StalkerForever','screensaver.video','script.ftvguide','script.pinsentry','script.skinshortcuts','script.trakt','userdata']
def run(): # Entry point
    plugintools.log("freshstart.run"); params=plugintools.get_params() # Get params
    if params.get("action") is None: main_list(params)
    else: action=params.get("action"); exec action+"(params)"
    plugintools.close_item_list()
def main_list(params): # Main menu
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All downloaded files removed, you have now refreshed your install"); plugintools.message(AddonTitle,"Kodi has been refreshed, please restart KODI!")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"Kodi has been refreshed, please [B]RESTART[/B] KODI!")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Please press back and run the update!",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","has not been changed"); plugintools.add_item(action="",title="Done",folder=False)
run()