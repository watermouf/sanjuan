# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.onlinecurses/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'onlinecurses'
VERSION = '0.0.1'
BASEURL = 'http://freevideolectures.com/'
ART = ADDON_PATH + "resources/icons/"


def Home_Menu():
    Menu('[B][COLOR white]PROGRA[/COLOR][COLOR red]MMING[/COLOR][/B]','',3,ART + 'pwdev.jpg',FANART,'')
    Menu('[B][COLOR white]MAT[/COLOR][COLOR red]HS[/COLOR][/B]','',4,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR white]ENGINE[/COLOR][COLOR red]ERING[/COLOR][/B]','',5,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR white]BUSI[/COLOR][COLOR red]NESS[/COLOR][/B]','',6,ART + 'bandm.jpg',FANART,'')
    Menu('[B][COLOR white]OTH[/COLOR][COLOR red]ERS[/COLOR][/B]','',7,ART + 'others.jpg',FANART,'')

def PWD():
    Menu('[B][COLOR blue]COMP[/COLOR][COLOR red]UTER[/COLOR][/B]','http://freevideolectures.com/Subject/Computer-Science',1,ART + 'pwdev.jpg',FANART,'')
    Menu('[B][COLOR blue]NET[/COLOR][COLOR red]WORK[/COLOR][/B]','http://freevideolectures.com/Subject/Networking',1,ART + 'pwdev.jpg',FANART,'')
    Menu('[B][COLOR blue]DESIG[/COLOR][COLOR red]NING[/COLOR][/B]','http://freevideolectures.com/Subject/Web-Designing',1,ART + 'pwdev.jpg',FANART,'')
    Menu('[B][COLOR blue]DA[/COLOR][COLOR red]TA[/COLOR][/B]','http://freevideolectures.com/Subject/Data-Structures',1,ART + 'pwdev.jpg',FANART,'')
    Menu('[B][COLOR blue]PROGRA[/COLOR][COLOR red]MMING[/COLOR][/B]','http://freevideolectures.com/Subject/Programming',1,ART + 'pwdev.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Math_Sc():
    Menu('[B][COLOR blue]ANAT[/COLOR][COLOR red]OMY[/COLOR][/B]','http://freevideolectures.com/Subject/Anatomy-Physiology',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]BIO TECHO[/COLOR][COLOR red]LOGY[/COLOR][/B]','http://freevideolectures.com/Subject/Bio-Technology',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]CHEMI[/COLOR][COLOR red]STRY[/COLOR][/B]','http://freevideolectures.com/Subject/Chemistry',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]GENE[/COLOR][COLOR red]TICS[/COLOR][/B]','http://freevideolectures.com/Subject/Genetics',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]HEA[/COLOR][COLOR red]LTH[/COLOR][/B]','http://freevideolectures.com/Subject/Health-Sciences',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]MATHMA[/COLOR][COLOR red]TICS[/COLOR][/B]','http://freevideolectures.com/Subject/Mathematics',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]MEDI[/COLOR][COLOR red]CINE[/COLOR][/B]','http://freevideolectures.com/Subject/Medicine',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]PHY[/COLOR][COLOR red]SICS[/COLOR][/B]','http://freevideolectures.com/Subject/Physics',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]CALCU[/COLOR][COLOR red]LUS[/COLOR][/B]','http://freevideolectures.com/Subject/Calculus',1,ART + 'mands.jpg',FANART,'')
    Menu('[B][COLOR blue]BIOL[/COLOR][COLOR red]OGY[/COLOR][/B]','http://freevideolectures.com/Subject/Biology',1,ART + 'mands.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Eng():
    Menu('[B][COLOR blue]ASTRO[/COLOR][COLOR red]NOMY[/COLOR][/B]','http://freevideolectures.com/Subject/Astronomy-Aerospace',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]ELECTR[/COLOR][COLOR red]ONICS[/COLOR][/B]','http://freevideolectures.com/Subject/Electronics',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]MECHA[/COLOR][COLOR red]NICAL[/COLOR][/B]','http://freevideolectures.com/Subject/Mechanical',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]SYST[/COLOR][COLOR red]EMS[/COLOR][/B]','http://freevideolectures.com/Subject/Signals-Systems',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]VLSI [/COLOR][COLOR red]ASIC DESIGN[/COLOR][/B]','http://freevideolectures.com/Subject/VLSI-and-ASIC-Design',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]ELECT[/COLOR][COLOR red]RICAL[/COLOR][/B]','http://freevideolectures.com/Subject/Electrical-Engineering',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]CIVIL ENGINE[/COLOR][COLOR red]ERING[/COLOR][/B]','http://freevideolectures.com/Subject/Civil-Engineering',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]METALL[/COLOR][COLOR red]URGY[/COLOR][/B]','http://freevideolectures.com/Subject/Metallurgy-and-Material-Science',1,ART + 'engin.jpg',FANART,'')
    Menu('[B][COLOR blue]OCEAN[/COLOR][COLOR red]OLOGY[/COLOR][/B]','http://freevideolectures.com/Subject/Ocean-Engineering',1,ART + 'engin.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Other():
    Menu('[B][COLOR blue]ECINO[/COLOR][COLOR red]MICS[/COLOR][/B]','http://freevideolectures.com/Subject/Economics',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]L[/COLOR][COLOR red]AW[/COLOR][/B]','http://freevideolectures.com/Subject/Law',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]PHILO[/COLOR][COLOR red]SOPHY[/COLOR][/B]','http://freevideolectures.com/Subject/Philosophy',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]PHYCH[/COLOR][COLOR red]OLOGY[/COLOR][/B]','http://freevideolectures.com/Subject/Psychology',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]SOCIAL SCI[/COLOR][COLOR red]ENCES[/COLOR][/B]','http://freevideolectures.com/Subject/Social-Sciences',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]HIST[/COLOR][COLOR red]ORY[/COLOR][/B]','http://freevideolectures.com/Subject/History',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]LITRA[/COLOR][COLOR red]TURE[/COLOR][/B]','http://freevideolectures.com/Subject/Literature',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR blue]LANGU[/COLOR][COLOR red]AGES[/COLOR][/B]','http://freevideolectures.com/Subject/Languages',1,ART + 'others.jpg',FANART,'')
    Menu('[B][COLOR red]Other[/COLOR][COLOR yello] Courses[/COLOR][/B]','http://freevideolectures.com/Subject/Other-Courses',1,ART + 'others.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def B_Man():
    Menu('[B][COLOR blue]BUSINNESS[/COLOR][COLOR red] MANAGE[/COLOR][COLOR white]MENT[/COLOR][/B]','http://freevideolectures.com/Subject/Business-Management',1,ART + 'bandm.jpg',FANART,'')
    Menu('[B][COLOR blue]ENTERPRE[/COLOR][COLOR red]NEURCHIP[/COLOR][/B]','http://freevideolectures.com/Subject/Entrepreneurship',1,ART + 'bandm.jpg',FANART,'')
    Menu('[B][COLOR blue]COMMUNI[/COLOR][COLOR red]CATION[/COLOR][/B]','http://freevideolectures.com/Subject/Communication-Skills',1,ART + 'bandm.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Main_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="cs-courses courses-grid">.+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        icon = icon.replace(' ','%20')
        Menu(name,url,2,icon,FANART,'')
    np = re.compile('<li><a href="(.+?)" class="footer_paginate">(.+?)</a><li>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if 'NEXT' in name:
                    Menu('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,1,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')					

def Second_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="lecture_menu">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li.+?><a href="(.+?)".+?>(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Play(name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    url = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0]
    url = url.replace('http://www.youtube.com/watch?v=','plugin://plugin.video.youtube/play/?video_id=')
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Home_Menu()
elif mode == 1 : Main_Menu(url)
elif mode == 2 : Second_Menu(url)
elif mode == 3 : PWD()
elif mode == 4 : Math_Sc()
elif mode == 5 : Eng()
elif mode == 6 : B_Man()
elif mode == 7 : Other()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
