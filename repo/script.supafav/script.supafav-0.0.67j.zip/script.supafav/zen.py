import xbmc, xbmcaddon, xbmcgui, xbmcplugin


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
		
params=get_params()
url=None
mode=None

try:        
        mode=int(params["mode"])
except:
        pass
	   
if mode==None:
        quit()
elif mode==10: #recent movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/",return)')   
elif mode==20: #recent movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=trending",return)')
elif mode==21: #recent tv
       #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.menu/?folder=TV Shows/Recently Added",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.1channel/?mode=GetFilteredResults&section=tv&sort=date",return)')
elif mode==22: #new tv shows
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=premiere",return)')
	   #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvmix/?mode=3&url=http%3a%2f%2fwww.watchepisodes1.com%2fhome%2fnew-series",return)')
elif mode==23: #movie years
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movieYears",return)')
elif mode==24: #movie genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movieGenres",return)')
elif mode==25: #tv genre
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvGenres",return)')
elif mode==26: #TV Networks
       #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV Shows/Networks",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvNetworks",return)')
	   
elif mode==27: #movie actors
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=moviePersons",return)')	 
elif mode==29: #boxsets
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.phstreams/?action=directory&url=http://tnpb.offshorepastebin.com/Directories/Movies%20Directories/Boxsets%20Directory.xml",return)')	   
elif mode==30: #search movies
       xbmc.executebuiltin('PlayMedia("plugin://plugin.video.zen/?action=movieSearch")')
       #xbmc.executebuiltin('ActivateWindow(10000)')
       #quit()
elif mode==31: #search tv
       xbmc.executebuiltin('PlayMedia("plugin://plugin.video.zen/?action=tvSearch")') 
       #quit()
elif mode==40: #movies root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies",return)')
elif mode==41: #movies browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Movies/Browse",return)')	 
elif mode==42: #movies random
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=channels",return)') 
elif mode==50: #tv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows",return)')	
elif mode==51: #tv browse
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=TV shows/Browse",return)')
elif mode==60: #livetv root
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV",return)')
elif mode==61: #livetv providers
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Providers",return)')   
elif mode==62: #livetv News
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=News",return)')
elif mode==63: #livetv Sports
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=Sports",return)') 
elif mode==64: #livetv Foregin
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Foregin",return)')
elif mode==65: #livetv Shows
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder=LiveTV/Shows",return)')
elif mode==70: #search widget
       xbmc.executebuiltin('ActivateWindow(1107)')
elif mode==71: #movies featured
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=featured",return)')
elif mode==72: #movies oscar 
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=tmdboscars",return)')
elif mode==73: #movies popular alltime
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=views",return)')
elif mode==74: #movies in theaters
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=theaters",return)')
elif mode==75: #movies popular
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=theaters",return)')	
elif mode==76: #tvshow  trending
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&amp;url=featured",return)')
elif mode==77: #tvshow  popular
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=popular",return)')
elif mode==78: #tvshow  new episodes
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=airing",return)')
elif mode==79: #tvshow  critics
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=rating",return)')
elif mode==80: #tvshow  critics
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=rating",return)')
elif mode==81: #Kids Newest Movies
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=http%3a%2f%2fwww.imdb.com%2fsearch%2ftitle%3ftitle_type%3dfeature%2ctv_movie%26languages%3den%26num_votes%3d100%2c%26release_date%3ddate%5b730%5d%2cdate%5b30%5d%26genres%3dfamily%26sort%3dmoviemeter%2casc%26count%3d40%26start%3d1",return)')
elif mode==82: #Kids Popular Movies
	   #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=http%3A%2F%2Fwww.imdb.com%2Fsearch%2Ftitle%3Fgenres%3Dfamily%26sort%3Dnum_votes,desc",return)')
	   #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=http%3A%2F%2Fwww.imdb.com%2Fsearch%2Ftitle%3Fgenres%3Dfamily%26sort%3Dmoviemeter,asc",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=http%3A%2F%2Fwww.imdb.com%2Fsearch%2Ftitle%3Fgenres%3Dfamily%26sort%3Dboxoffice_gross_us,desc",return)')
elif mode==83: #Kids tv cartoons
	   #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=http%3a%2f%2fwww.imdb.com%2fsearch%2ftitle%3ftitle_type%3dtv_series%2cmini_series%26release_date%3d%2cdate%5b0%5d%26genres%3danimation%26%26certificates%3dus%3atv_g%26sort%3dmoviemeter%2casc%26count%3d50%26start%3d1",return)')
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=tvshows&url=http%3A%2F%2Fwww.imdb.com%2Fsearch%2Ftitle%3Ftitle_type%3Dtv_series,mini_series%26genres%3Danimation%26%26certificates%3Dus%3Atv_g%26sort%3Dmoviemeter,asc%26count%3D40",return)')
elif mode==84: #Kids Disney
	   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zen/?action=movies&url=tmdbdisney",return)')
elif mode==101: #WeatherSettings
	   xbmc.executebuiltin('Addon.OpenSettings(script.supafav),return')	   
if mode==94: #search exodus tv
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/?action=tvSearch",return)')	   
if mode==95: #search exodus movies
       xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.exodus/?action=movieSearch",return)')    

	   #<favourite name="" thumb="">PlayMedia(&quot;plugin://script.supafav/?url=null&mode=19&quot;)</favourite>	   
xbmcplugin.endOfDirectory(int(sys.argv[1]))
