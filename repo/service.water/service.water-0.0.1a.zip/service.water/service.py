import os, re, shutil, time, xbmc
try:
	import json as simplejson 
except:
	import simplejson

#file = xbmc.translatePath('special://home/addons/service.openeleq/guisettings.xml')
path = xbmc.translatePath('special://home/addons/service.water')
#zip = xbmc.translatePath('special://home/addons/packages/Quix.zip')
servicepy = xbmc.translatePath('special://home/addons/service.water/service.py')

#false list ?
#bflist = ["DisableGlobalSearch","HomepageHideRecentlyAddedVideo","HomepageHideRecentlyAddedAlbums","UseCustomBackground","UseCustomBackgroundFolder","HideBackGroundFanart","ShowBackgroundVideo","ShowBackgroundVis","SkinMod","KidsProfile","homepageMusicinfo","homepageVideoinfo","HomeMenuNoMovieButton","HomeMenuNoTVShowButton","HomeMenuNoWeatherButton","HomeMenuNoCustomHomeButton1","HomeMenuNoPicturesButton","HomeMenuNoCustomHomeButton2","HomeMenuNoRadioButton","HomeMenuNoCustomHomeButton3","HomeMenuNoTVButton","HomeMenuNoCustomHomeButton4","HomeMenuNoVideosButton","HomeMenuNoCustomHomeButton5","HomeMenuNoCustomHomeButton6","HomeMenuNoCustomHomeButton7","HomeMenuMusicVideosButton","HomeMenuNoCustomHomeButton8","HomeMenuNoMusicButton","HomeMenuNoCustomHomeButton9","HomeMenuNoProgramsButton","HomeMenuNoCustomHomeButton10","HomeMenuNoDVDButton","HomeMenuNoSystemButton","Favourite1","Favourite2","Favourite3","Favourite4","Favourite5","Favourite6","Favourite7","Favourite11","Favourite12","Favourite13","Favourite14","Favourite15","Favourite16","Favourite17","Favourite21","Favourite22","Favourite23","Favourite24","Favourite25","Favourite26","Favourite27","Favourite31","Favourite32","Favourite33","Favourite34","Favourite35","Favourite36","Favourite37","HideFilenameFlagging","View508HideInfo","ActivateTvTunes","XXX","SuperShortcuts","Show_SlideShow_Paused","WindowedTrailer","Use_Startup_Playlist","AutoSubSearch","DeveloperMode","EnableDeveloper","HideVisualizationFanart","kioskmode","AnimeWindowXMLDialogClose","FavouriteVideoAddons","FavouriteMusicAddons","FavouritePictureAddons"]

bflist = ["DisableGlobalSearch"]
#true list ?
#blist = ["MusicFullscreen","homepageWeatherinfo","SystemDate","SystemWeatherinfo","AutoScroll","FirstTimeRun","ArtistSlideshow","SkinMod"]
btlist = ["HideHomeFloor","LowerMainMenuBar", "HideTopLeftWindows", "AllScreenTopLeftWidget", "HidePageCountInfo"]
# variable


moviemenu = ["HomeItem.1.Label|Movies","HomeItem.1.sub|Movies","HomeItem.1.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=40&url=null"",return)",          "SubMovies.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubMovies.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=20"",return)",       "SubMovies.2.Label|By [B][COLOR white]Year[/COLOR][/B]","SubMovies.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=23"",return)",        "SubMovies.3.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubMovies.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=24"",return)",           "SubMovies.4.Label|By [B][COLOR white]Actors[/COLOR][/B]","SubMovies.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=27"",return)",           "SubMovies.5.Label|[B][COLOR white]Search [COLOR steelblue]Movies[/COLOR][/B]","SubMovies.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=30"",return)",           "SubMovies.6.Label|Hidden","SubMovies.6.Path|Hidden"]

tvmenu = ["HomeItem.2.Label|TV Shows","HomeItem.2.sub|TVShows","HomeItem.2.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=50&url=null"",return)",          "SubTVShows.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubTVShows.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=21"",return)",          "SubTVShows.2.Label|[B][COLOR white]New[/COLOR][/B] Shows","SubTVShows.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=22"",return)",        "SubTVShows.3.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubTVShows.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=25"",return)",          "SubTVShows.4.Label|[B]By [COLOR white]Network[/COLOR][/B]","SubTVShows.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=26"",return)",        "SubTVShows.5.Label|[B][COLOR white]Search[/COLOR] [COLOR steelblue]TV[/COLOR][/B]","SubTVShows.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=40"",return)"]

livemenu = ["HomeItem.3.Widget|plugin://plugin.program.super.favourites/?folder=liveTV/Providers","HomeItem.3.Label|Live TV","HomeItem.3.sub|LiveTV","HomeItem.3.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=60&url=null"",return)",          "SubLiveTV.1.Label|[B]N[COLOR white]ews[/COLOR][/B]","SubLiveTV.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=62"",return)",          "SubLiveTV.2.Label|[B]S[COLOR white]ports[/COLOR][/B]","SubLiveTV.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=63"",return)",        "SubLiveTV.3.Label|[B]S[COLOR white]hows[/COLOR][/B]","SubLiveTV.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=65"",return)",          "SubLiveTV.4.Label|[B]F[COLOR white]oreign[/COLOR][/B]","SubLiveTV.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=64"",return)",        "SubLiveTV.5.Label|Hidden","SubLiveTV.5.Path|Hidden"]

moremenu = ["HomeItem.4.Label|More","HomeItem.4.Widget|Weather", "HomeItem.4.Addon|AddonSetTwelve", "HomeItem.4.sub|Settings","HomeItem.4.path|ActivateWindow(Settings))", "HomeItem.4.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=more"",return)",         "SubSettings.1.Label|[B]S[COLOR white]ettings[/COLOR][/B]","SubSettings.1.Path|ActivateWindow(Settings)", "SubSettings.2.Path|Hidden", "SubSettings.3.Path|Hidden", "SubSettings.4.Path|Hidden", "SubSettings.5.Path|Hidden", "SubSettings.6.Path|Hidden",      "AddonSetTwelve.1.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/"" ,return)", "AddonSetTwelve.1.label|YouTube", "AddonSetTwelve.1.Icon|http://www.usacapitol.com/SiteAssets/stay-connected/youtube-logo.png",                  "AddonSetTwelve.2.label|Music", "AddonSetTwelve.2.Icon|",                     "AddonSetTwelve.4.label|KidsTV", "AddonSetTwelve.4.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/KidsTV"",return)", "AddonSetTwelve.4.Icon|http://icons.iconarchive.com/icons/martin-berube/people/256/kid-icon.png" ,     "AddonSetTwelve.3.label|Documentaries","AddonSetTwelve.3.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/Documentaries"",return)", "AddonSetTwelve.3.Icon|https://solutionsmedia.cbcrc.ca/Pictures/chaineslogos/CBC_documentary_blanc_15.png",                  "AddonSetTwelve.5.Path|https://solutionsmedia.cbcrc.ca/Pictures/chaineslogos/CBC_documentary_blanc_15.png", "AddonSetTwelve.5.label|Stand-Up","AddonSetTwelve.5.Path|ActivateWindow(10025,""plugin://plugin.video.phstreams/?action=directory&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fStandup.xml"",return)", "AddonSetTwelve.5.Icon|https://lh6.ggpht.com/JH8vf9T54XQET1h-BgpvZrXedGkWEqG-K9DSgf_TXlU2r0WpM3NlZ817a3F9Ch83aBg=w150","AddonSetTwelve.6.Path|", ]

hiddenmenu = ["GlobalBackgroundPath|special://home/addons/script.supafav/BG/","TopLeftHomeInfo|Weather","HomeItem.5.path|","HomeItem.6.path|","HomeItem.7.path|","HomeItem.8.path|","HomeItem.9.path|","HomeItem.10.path|","HomeItem.11.path|","HomeItem.12.path|"]



def read_from_file(path, silent=False):
	try:
		f = open(path, 'r')
		r = f.read()
		f.close()
		return str(r)
	except:
		return None

def getSetting(setting):
	try:
		setting = '"%s"' % setting 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None

def setSetting(setting, value):
	setting = '"%s"' % setting
	value = '"%s"' % value
	query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
	response = xbmc.executeJSONRPC(query)

if __name__ == '__main__':
	xbmc.executebuiltin("ActivateWindow(Home)")
	setting = 'lookandfeel.skin'
	value = 'skin.water2'
	current = getSetting(setting)
	setSetting(setting, value)
	while current != 'skin.water2':
		xbmc.executebuiltin("Action(Select)")
		current = getSetting(setting)
	for item in bflist:
		xbmc.executebuiltin("Skin.Reset("+item+")")
	for item in btlist:
		xbmc.executebuiltin("Skin.SetBool("+item+")")
	for item in moviemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in tvmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in livemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in moremenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in hiddenmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	#shutil.rmtree(path)
	os.remove(servicepy)
	time.sleep(1)
	xbmc.executebuiltin("Notification(Quix Installed,Enjoy!,5000,special://profile/icon.png)")