import xbmc

def logoff():
	xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/play/?playlist_id=PL4166A6B67CF5C6AE&amp;order=shuffle&amp;play=1")')
if not xbmc.Player().isPlayingAudio():
	logoff()